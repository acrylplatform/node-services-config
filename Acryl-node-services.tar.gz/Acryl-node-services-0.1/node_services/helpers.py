import datetime
import json
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
import urllib.request
from typing import Optional

from node_services.api import LoggerAPI
from node_services.service_runners import PidServiceRunner
from node_services.config import config, RESTART_REQUIRED_FILENAME, ACTION_LOG_FILENAME, LOCK_ACTIONS


def get_runner() -> PidServiceRunner:
    """
    Get runner (currently PidServiceRunner)
    :return: runner instance
    """
    runner = PidServiceRunner(
        config["executable"]["path"],
        executable_args=config["executable"]["args"],
        env_args=config["executable"]["environment"],
        pid_file=config["executable"]["pid_file"],
        log_file=config["executable"]["logfile"],
        config_file=config["executable"]["config_file"],
        wait_timeout=config["executable"]["wait_start_timeout"]
    )
    return runner


def get_node_address_data() -> dict:
    """
    Get node address data from json
    :return:
    """
    wallet_file_path = config["node"]["wallet_data_file_path"]
    with open(wallet_file_path, 'r') as wallet_file:
        wallet_data = json.load(wallet_file)

    return wallet_data


def update_file(url: str, save_path: str, file_name: str, buffer_size: int=4096) -> None:
    """
    Download and save file
    :param url: file url
    :param save_path: save path for file
    :param file_name: file name for saving
    :param buffer_size: buffer size
    :return:
    """
    with urllib.request.urlopen(url) as request:
        size = request.length
        target_file_path = os.path.join(save_path, file_name)
        with open(target_file_path, 'wb') as target_file:
            while request.length > 0:
                content = request.read(buffer_size)
                target_file.write(content)
                percents = round(((size-request.length)/size)*100)
                logging.debug(f"{percents}%")

    return


# TODO: HOCON parser
def update_miner_address(seed: str) -> None:
    """
    Update address for miner config
    :param seed: seed in base58
    :return:
    """
    logging.debug(f"setting seed {seed} to miner config")
    with open(config["executable"]["config_file"], 'r+') as config_file:
        config_file_contents = config_file.read()
        new_content = re.sub("seed = \".*?\"", f"seed = \"{seed}\"", config_file_contents)
        config_file.seek(0)
        config_file.write(new_content)
        config_file.flush()

    return


# TODO: check response body
def get_network_connection_status() -> bool:
    """
    Test network connectivity
    :return:
    """
    test_servers = config["network"]["test_servers"]
    for test_server in test_servers:
        try:
            urllib.request.urlopen(test_server, timeout=5)
        except Exception as e:
            show_message(f"{test_server} connection failed: {e}")
            return False

    return True


def get_last_update() -> Optional[str]:
    """
    Get last update date
    :return:
    """
    try:
        with open('LAST_UPDATE', 'r') as update_date_file:
            last_update_date = update_date_file.read().rstrip('\n')
    except OSError:
        return None

    return last_update_date


def print_to_console(message: str) -> None:
    """
    Show message to all consoles
    Requires root permissions or user 'tty' group presence
    :param message:
    :return:
    """
    with open('/dev/tty0', 'w') as tty_file:
        tty_file.write(message)
        tty_file.flush()

    return


def get_internal_ip():
    """
    Get internal (or also external) IP
    :return:
    """
    socket_object = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        socket_object.connect(("8.8.8.8", 80))
        ip_address = socket_object.getsockname()[0]
        socket_object.close()
    except Exception:
        ip_address = "127.0.0.1"

    return ip_address


def log_to_api(endpoint_name: str, params: dict):
    """

    :param endpoint_name:
    :param params:
    :return:
    """
    logger = LoggerAPI(config["network"]["stats_api_addresses"])
    try:
        logger.api_request(endpoint_name, params=params, method="POST")
    except Exception as e:
        logging.debug(f"api logging error: {e}")
        return False

    return True


def show_message(message: str, level: str='info') -> None:
    """
    Show message on all consoles or only current
    :param message:
    :param level:
    :return:
    """
    if os.isatty(sys.stdout.fileno()):
        level_int = logging.getLevelName(level=level.upper())
        logging.log(level_int, message)
    else:
        print_to_console(message)
        print_to_console('\n')

    return


def restart_notification() -> None:
    """
    Notify if service restart required
    :return:
    """
    current_date_time = datetime.datetime.now()
    with open(RESTART_REQUIRED_FILENAME, 'w') as restart_file:
        restart_file.write(str(current_date_time))

    shutil.chown(RESTART_REQUIRED_FILENAME, config["node-services"]["user"], config["node-services"]["group"])


def update_cron_commands() -> None:
    """
    Update crontab from config
    :return:
    """
    cron_jobs = "\n".join(config["cron"]["jobs"])
    with open(config["cron"]["crontab_file_path"], 'w') as crontab_file:
        crontab_file.write(cron_jobs)
        crontab_file.write('\n')

    subprocess.check_output(['crontab', config["cron"]["crontab_file_path"]])
    return


def humanize_size(num, suffix='B'):
    for unit in ('', 'K', 'M', 'G', 'T', 'P', 'E', 'Z'):
        if abs(num) < 1024.0:
            return "%3.1f%s%s" % (num, unit, suffix)

        num /= 1024.0

    return "%.1f%s%s" % (num, 'Yi', suffix)


def get_disk_data(path: str, humanize=False) -> dict:
    total, used, free = shutil.disk_usage(path)
    disk_data = {
        "total": humanize_size(total) if humanize else total,
        "used": humanize_size(used) if humanize else used,
        "free": humanize_size(free) if humanize else free,
    }

    return disk_data


def check_pid_lock_presence(lock_file_name: str) -> bool:
    """
    Check lock file is present
    :param lock_file_name:
    :return:
    """
    if not os.path.exists(lock_file_name):
        return False

    with open(lock_file_name, 'r') as lock_file:
        locking_pid = lock_file.read()
        try:
            os.kill(int(locking_pid), 0)
        except Exception:
            os.remove(lock_file_name)
            return False
        else:
            return True


def set_lock(lock_file_name: str) -> bool:
    """
    Create lock file
    :param lock_file_name:
    :param pid:
    :return:
    """
    if check_pid_lock_presence(lock_file_name):
        logging.debug("lock file already exists")
        return False

    with open(lock_file_name, 'w') as lock_file:
        lock_pid = os.getpid()
        lock_file.write(str(lock_pid))

    logging.debug("lock file created")

    return True


def release_lock(lock_file_name: str) -> bool:
    """
    Release lock for current process
    :param lock_file_name:
    :return:
    """
    if check_pid_lock_presence(lock_file_name):
        logging.debug("lock file not found")
        return True

    with open(lock_file_name, 'r') as lock_file:
        locking_pid = lock_file.read()
        if int(locking_pid) != os.getpid():
            return False

    os.remove(lock_file_name)
    logging.debug("lock file removed")
    return True


def get_lock() -> Optional[tuple]:
    """
    Get any lock
    :return: tuple(lock_pid, locking action)
    """
    for lock_file_name, action in LOCK_ACTIONS.items():
        if check_pid_lock_presence(lock_file_name):
            with open(lock_file_name, 'r') as lock_file:
                pid = int(lock_file.read())
                return pid, action

    return


def log_action(name: str, status: str, subject: str, value: str):
    data = {"name": name, "status": status, "subject": subject, value: value}
    with open(ACTION_LOG_FILENAME, 'a') as action_log_file:
        action_log_file.write(json.dumps(data))

    return


def get_last_action():
    try:
        with open(ACTION_LOG_FILENAME, 'r') as action_log_file:
            first_line = action_log_file.readline()
            action_log_file.seek(-2, os.SEEK_END)
            while action_log_file.read(1) != b"\n":
                action_log_file.seek(-2, os.SEEK_CUR)

            last_line = action_log_file.readline()

    except (IOError, ValueError):
        return

    dict_data = json.loads(last_line)
    return dict_data
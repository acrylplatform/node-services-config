import glob
import hashlib
import json
import logging
import os
import shutil
import sys
import tempfile
import uuid
from typing import Optional

from node_services.config import config
from node_services.config import VERSIONS_FILE_URLS
from node_services.helpers import show_message, update_file, restart_notification, update_cron_commands

__version__ = '0.1'
__author__ = 'DPTheinvaders'

try:
    from pip import main as pip_main
except ImportError:
    from pip._internal import main as pip_main


class UpdateError(Exception):

    pass


class Updater(object):

    UPDATE_LOCK_FILE_NAME = 'UPDATING'

    def __init__(self, temp_path_prefix=''):
        self.temp_dir = tempfile.mkdtemp(prefix=temp_path_prefix)
        self.update_lock_file = None
        self.current_versions_file = None
        self.current_pid = os.getpid()
        self._file_update_callbacks = (
            ("node-service-package", self._package_update_callback),
            ("node-service-config", self._node_services_config_update_callback)
        )

    def _node_services_config_update_callback(self, file_data: dict):
        """

        :param file_data:
        :return:
        """
        update_cron_commands()
        return

    def update(self):
        """
        Update files
        :return:
        """
        remote_versions = self.get_remote_versions()
        required_update_files = self.check_versions(remote_versions)
        if not required_update_files:
            show_message("No file available to update")
            return 0

        if os.path.exists(self.UPDATE_LOCK_FILE_NAME):
            with open(self.UPDATE_LOCK_FILE_NAME, 'r') as lock_file:
                update_pid_string = lock_file.read()

            try:
                update_pid = int(update_pid_string)
                os.kill(update_pid, 0)
            except Exception:
                try:
                    os.remove(self.UPDATE_LOCK_FILE_NAME)
                except FileNotFoundError:
                    pass
            else:
                show_message(f"update is already started (pid {update_pid})")
                return 1

        self.update_lock_file = open(self.UPDATE_LOCK_FILE_NAME, 'w')
        self.update_lock_file.write(str(self.current_pid))
        self.backup_current_files(required_update_files)
        self.download_files(required_update_files)
        self.move_files_to_destination(required_update_files)
        self.run_callbacks(required_update_files)

        return 0

    def move_files_to_destination(self, files_data):
        """

        :param files_data:
        :return:
        """
        show_message("Moving files to destination...")
        for file_name, file_data in files_data.items():
            old_file_path = os.path.join(self.temp_dir, file_data["name"])
            new_file_path = os.path.join(file_data["save_path"], file_data["name"])
            shutil.move(old_file_path, new_file_path)

        return

    def run_callbacks(self, files_data):
        """

        :param files_data:
        :return:
        """
        show_message("Running update callbacks...")
        for file_name, file_data in files_data.items():
            if not file_data["has_update_callback"]:
                continue

            update_callback = dict(self._file_update_callbacks).get(file_name)
            if not update_callback:
                show_message(f"Callback for {file_name} not found")

            update_callback(file_data)

        return

    def download_files(self, required_update_files: dict):
        """
        Download files
        :param required_update_files:
        :return:
        """
        for file_name, file_data in required_update_files.items():
            file_downloaded = False
            for url in file_data["urls"]:
                try:
                    update_file(url, self.temp_dir, file_data["name"])
                    file_hash = self.get_file_sha265(
                        os.path.join(self.temp_dir, file_data["name"])
                    )
                    if not file_data["sha256"] == file_hash:
                        show_message(f"sha256 incorrect: ({file_hash} != {file_data['sha256']})")
                        show_message("Trying next URL")
                        continue

                except Exception as e:
                    show_message(f"Download from '{url}' failed. Trying next URL")
                    continue
                else:
                    show_message(f"File '{file_data['name']} downloaded successfully'")
                    file_downloaded = True
                    break

            if not file_downloaded:
                raise UpdateError(f"File '{file_data['name']}' failed to update")

        return

    @staticmethod
    def check_versions(remote_versions_data: dict) -> dict:
        """
        Check remote and local file versions
        :param remote_versions_data:
        :return:
        """
        show_message("Comparing versions...")
        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        if not os.path.exists(current_versions_file_path):
            show_message("No version file found. Updating everything")
            return remote_versions_data

        with open(current_versions_file_path, 'r') as current_versions_file:
            versions_data = json.load(current_versions_file)

        updates = {}
        for file_name, file_data in versions_data.items():
            if file_data["version"] < remote_versions_data[file_name]["version"]:
                updates[file_name] = remote_versions_data[file_name]

            if file_data["version"] > remote_versions_data[file_name]["version"]:
                show_message(f"'{file_name}' local version higher than remote)", 'warning')

        return updates

    def backup_current_files(self, files_data: dict):
        backup_directory_name = 'backup_dir'
        os.mkdir(backup_directory_name)
        for file_name, file_data in files_data:
            if file_data["skip_backup"]:
                show_message(f"Backup of '{file_data['name']}' is not required")
                continue
            else:
                show_message(f"Backing up '{file_data['name']}'")
                file_path = os.path.join(file_data["save_path"], file_data["name"])
                shutil.move(file_path, backup_directory_name)

        return

    @staticmethod
    def get_remote_versions() -> Optional[dict]:
        """
        Get versions from remote file
        :return:
        """
        show_message("Getting versions file...")
        data = None
        for versions_file_url in VERSIONS_FILE_URLS:
            show_message(f"Trying '{versions_file_url}'")
            temp_dir = tempfile.gettempdir()
            temp_file_name = uuid.uuid4().hex
            try:
                update_file(versions_file_url, temp_dir, temp_file_name)
            except Exception as e:
                show_message(f"unable to download versions file: {e}")
                continue

            temp_file_path = os.path.join(temp_dir, temp_file_name)
            with open(temp_file_path, 'r') as temp_config_file:
                data = json.load(temp_config_file)

            return data

        if data is None:
            raise UpdateError("Versions file is not loaded correctly")

    @staticmethod
    def get_file_sha265(hashing_file_path: str) -> str:
        """
        Compare SHA256
        :param source_hash: hash value
        :param hashing_file_path: file
        :return:
        """
        hash_ = hashlib.sha256()
        with open(hashing_file_path, 'rb') as hashing_file:
            while True:
                data = hashing_file.read(65536)
                if not data:
                    break

                hash_.update(data)

        hash_digest = hash_.hexdigest()
        return hash_digest

    def _package_update_callback(self, file_data: dict) -> bool:
        """
        Update node-services package
        :param file_data:
        :return:
        """
        try:
            return_code = pip_main(
                ["install", os.path.join(file_data["save_path"], file_data["name"]), "--upgrade"]
            )
        except SystemExit:
            return False
        else:
            return return_code == 0

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        shutil.rmtree(self.temp_dir)

        if self.current_versions_file:
            self.current_versions_file.close()

        if self.update_lock_file:
            self.update_lock_file.close()
            try:
                os.remove(self.UPDATE_LOCK_FILE_NAME)
            except FileNotFoundError:
                pass


def perform_update():
    try:
        with Updater() as updater:
            return_code = updater.update()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        file_name = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        show_message(f"Update failed: {file_name} ({exc_tb.tb_lineno}): {exc_type}: {e}")
        logging.exception()
        return_code = 1

    return return_code


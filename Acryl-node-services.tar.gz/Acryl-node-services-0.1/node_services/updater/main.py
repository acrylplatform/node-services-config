import glob
import hashlib
import json
import logging
import os
import shutil
import sys
import tempfile
import uuid
from typing import Optional

from node_services.config import config, UPDATE_LOCK_FILE_NAME
from node_services.helpers import show_message, update_file, restart_notification, update_cron_commands, set_lock, \
    release_lock, get_lock

__version__ = '0.1'
__author__ = 'DPTheinvaders'

try:
    from pip import main as pip_main
except ImportError:
    from pip._internal import main as pip_main


class UpdateError(Exception):

    pass


class Updater(object):

    BACKUP_DIRECTORY_NAME = 'backup_dir'

    def __init__(self, temp_path_prefix=''):
        self.temp_dir = tempfile.mkdtemp(prefix=temp_path_prefix)
        self._file_update_callbacks = (
            ("node-service-package", self._package_update_callback),
            ("node-service-config", self._node_services_config_update_callback)
        )

    def _node_services_config_update_callback(self, file_data: dict):
        """

        :param file_data:
        :return:
        """
        update_cron_commands()
        return True

    def update(self):
        """
        Update files
        :return:
        """
        remote_versions = self.get_remote_versions()
        required_update_files = self.check_versions(remote_versions)
        if not required_update_files:
            show_message("No file available to update")
            return 0

        local_versions = self.get_local_file_versions()
        if not local_versions:
            show_message("No local file versions found")
            raise UpdateError()

        self.backup_current_files(local_versions)
        self.download_files(required_update_files)
        self.move_files_to_destination(required_update_files)
        self.run_callbacks(required_update_files)

        return 0

    def move_files_to_destination(self, files_data):
        """

        :param files_data:
        :return:
        """
        show_message("Moving files to destination...")
        for file_name, file_data in files_data.items():
            old_file_path = os.path.join(self.temp_dir, file_data["name"])
            new_file_path = os.path.join(file_data["save_path"], file_data["name"])
            shutil.move(old_file_path, new_file_path)

        return

    def run_callbacks(self, files_data):
        """

        :param files_data:
        :return:
        """
        show_message("Running update callbacks...")
        for file_name, file_data in files_data.items():
            if not file_data["has_update_callback"]:
                continue

            update_callback = dict(self._file_update_callbacks).get(file_name)
            if not update_callback:
                show_message(f"Callback for {file_name} not found")

            update_callback(file_data)

        return

    def download_files(self, required_update_files: dict):
        """
        Download files
        :param required_update_files:
        :return:
        """
        for file_name, file_data in required_update_files.items():
            file_downloaded = False
            show_message(f"Downloading '{file_data['name']}...")
            for url in file_data["urls"]:
                show_message(f"Trying '{url}...")
                try:
                    update_file(url, self.temp_dir, file_data["name"])
                    show_message("Comparing file SHA256...")
                    file_hash = self.get_file_sha265(
                        os.path.join(self.temp_dir, file_data["name"])
                    )
                    if not file_data["sha256"] == file_hash:
                        show_message(f"sha256 incorrect: ({file_hash} != {file_data['sha256']})")
                        show_message("Trying next URL")
                        continue

                except Exception as e:
                    show_message(f"Download from '{url}' failed. Trying next URL")
                    continue
                else:
                    show_message(f"File '{file_data['name']} downloaded successfully")
                    file_downloaded = True
                    break

            if not file_downloaded:
                raise UpdateError(f"File '{file_data['name']}' failed to update")

        return

    @staticmethod
    def check_versions(remote_versions_data: dict) -> dict:
        """
        Check remote and local file versions
        :param remote_versions_data:
        :return:
        """
        show_message("Comparing versions...")
        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        if not os.path.exists(current_versions_file_path):
            show_message("No version file found. Updating everything")
            return remote_versions_data

        with open(current_versions_file_path, 'r') as current_versions_file:
            versions_data = json.load(current_versions_file)

        updates = {}
        for file_name, file_data in versions_data.items():
            if file_data["version"] < remote_versions_data[file_name]["version"]:
                updates[file_name] = remote_versions_data[file_name]

            if file_data["version"] > remote_versions_data[file_name]["version"]:
                show_message(f"'{file_name}' local version higher than remote)", 'warning')

        return updates

    def backup_current_files(self, files_data: dict):
        """
        Move old files to backup directory
        :param files_data:
        :return:
        """
        try:
            os.mkdir(self.BACKUP_DIRECTORY_NAME)
        except FileExistsError:
            show_message("Found old backup files directory")

        for file_id, file_data in files_data.items():
            if file_data["skip_backup"]:
                show_message(f"Backup of '{file_data['name']}' is not required")
                continue
            else:
                show_message(f"Backing up '{file_data['name']}'")
                file_path = os.path.join(file_data["save_path"], file_data["name"])
                shutil.move(file_path, self.BACKUP_DIRECTORY_NAME)
                show_message(f"'{file_data['name']}' backed up")

        return

    def restore_backup(self):
        """
        Move backed up files from backup directory
        :return:
        """
        if not os.path.exists(self.BACKUP_DIRECTORY_NAME):
            show_message("Backup directory doesn't exists!")
            return False

        local_versions = self.get_local_file_versions()
        if not local_versions:
            show_message("No local versions file found")
            return False

        for file_id, file_data in local_versions.items():
            show_message(f"Restoring '{file_id}'")
            backup_file_path = os.path.join(self.BACKUP_DIRECTORY_NAME, file_data["name"])
            target_file_path = os.path.join(file_data["save_path"], file_data["name"])
            shutil.move(backup_file_path, target_file_path)
            show_message(f"'{file_id}' restored")

        return True

    def clear_backup(self) -> bool:
        """
        Remove backup files
        :return:
        """
        if os.path.exists(self.BACKUP_DIRECTORY_NAME):
            shutil.rmtree(self.BACKUP_DIRECTORY_NAME)
            return True

        return False

    @staticmethod
    def get_local_file_versions() -> Optional[dict]:
        """
        Get local versions from file
        :return:
        """
        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        if not os.path.exists(current_versions_file_path):
            return None

        with open(current_versions_file_path, 'r') as current_versions_file:
            versions_data = json.load(current_versions_file)

        return versions_data


    @staticmethod
    def get_remote_versions() -> Optional[dict]:
        """
        Get versions from remote file
        :return:
        """
        show_message("Getting versions file...")
        data = None
        for versions_file_url in config["updates"]["versions_files"]:
            show_message(f"Trying '{versions_file_url}'")
            temp_dir = tempfile.gettempdir()
            temp_file_name = uuid.uuid4().hex
            try:
                update_file(versions_file_url, temp_dir, temp_file_name)
            except Exception as e:
                show_message(f"unable to download versions file: {e}")
                continue

            temp_file_path = os.path.join(temp_dir, temp_file_name)
            with open(temp_file_path, 'r') as temp_config_file:
                data = json.load(temp_config_file)

            return data

        if data is None:
            raise UpdateError("Versions file is not loaded correctly")

    @staticmethod
    def get_file_sha265(hashing_file_path: str) -> str:
        """
        Compare SHA256
        :param source_hash: hash value
        :param hashing_file_path: file
        :return:
        """
        hash_ = hashlib.sha256()
        with open(hashing_file_path, 'rb') as hashing_file:
            while True:
                data = hashing_file.read(65536)
                if not data:
                    break

                hash_.update(data)

        hash_digest = hash_.hexdigest()
        return hash_digest

    def _package_update_callback(self, file_data: dict) -> bool:
        """
        Update node-services package
        :param file_data:
        :return:
        """
        try:
            return_code = pip_main(
                ["install", os.path.join(file_data["save_path"], file_data["name"]), "--upgrade"]
            )
        except SystemExit:
            return False
        else:
            return return_code == 0

    def __enter__(self):
        lock = get_lock()
        if lock:
            show_message(f"Lock found: {lock[1]} (pid {lock[0]})")
            raise UpdateError("Another action is running")

        if not set_lock(UPDATE_LOCK_FILE_NAME):
            raise IOError("Can't set update process lock")

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        shutil.rmtree(self.temp_dir)
        if not release_lock(UPDATE_LOCK_FILE_NAME):
            raise IOError("Can't release update process lock")


def perform_update():
    updater_object = Updater()
    try:
        with updater_object as updater:
            return_code = updater.update()

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        file_name = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        show_message(f"Update failed: {file_name} ({exc_tb.tb_lineno}): {exc_type}: {e}")
        logging.exception("Error")
        return_code = 1
        updater_object.restore_backup()
    else:
        show_message("Update finished successfully")
        show_message("Removing old backup...")
        updater_object.clear_backup()
        show_message("Removed successfully")

    return return_code


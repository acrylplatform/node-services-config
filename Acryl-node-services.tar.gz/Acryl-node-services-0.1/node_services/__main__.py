__version__ = '0.1'
__author__ = 'DPTheinvaders'


import argparse
import logging
import sys

from node_services.commands.check_service import CheckServiceCommand
from node_services.commands.info import StatusCommand, InfoCommand
from node_services.commands.initialize import InitializeCommand
from node_services.commands.restart_service import RestartServiceCommand
from node_services.commands.stop_service import StopServiceCommand
from node_services.commands.update import UpdateCommand
from node_services.commands.withdraw_acryl import WithdrawAcrylCommand
from node_services.config import config
from node_services.commands.check_files import CheckFilesCommand



base_parser = argparse.ArgumentParser(description='Acryl node script', prog='acryl-node')
base_parser.add_argument(
    '-c', '--config-file', metavar='CONFIG_FILE_PATH', help='config file for %(prog)s',
    type=argparse.FileType('r+'), default='config.json'
)
base_parser.add_argument('-v', '--verbose', action='store_true', help='verbose output')
base_parser.add_argument('--version', action='version', version=f"%(prog)s {__version__}", help='version')

subparsers = base_parser.add_subparsers(help='available commands', dest='command_name')
subparsers.required = True

initialize_parser = subparsers.add_parser('initialize', help='initialize help')
initialize_parser.add_argument("path", metavar="PATH", type=str, help="mounted device filesystem path")
initialize_parser.add_argument(
    "-f", '--force', action='store_true', help="force initialize or reinitialize"
)

check_service_parser = subparsers.add_parser(
    'check_service', help='check service is running. start if it is not'
)

restart_service_parser = subparsers.add_parser('restart_service', help='restart service')
restart_service_parser.add_argument(
    "-f", '--force', action='store_true', help="force restart %(prog)s (SIGKILL)"
)

update_parser = subparsers.add_parser('update', help='update help')

withdraw_acryl_parser = subparsers.add_parser('withdraw_acryl', help='withdraw acryl')

stop_service_parser = subparsers.add_parser('stop_service', help='stop service')
stop_service_parser.add_argument(
    "-f", '--force', action='store_true', help="force stop %(prog)s (SIGKILL)"
)

status_parser = subparsers.add_parser('status', help='service status')

info_parser = subparsers.add_parser('info', help='node info')

check_files_parser = subparsers.add_parser(
    'check_files', help='check special files (initialization, withdraw wallet) in directory and preform actions'
)
check_files_parser.add_argument(
    "--path", metavar="PATH", type=str, help="mounted device filesystem path", required=False
)


def setup_logging(verbose: bool=False):
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s : %(name)s : %(levelname)s : %(message)s')
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)


def main():
    args = base_parser.parse_args()
    setup_logging(args.verbose)

    if args.config_file:
        config.load(args.config_file)
    else:
        logging.info("no config file specified, using defaults")

    commands = {
        "initialize": InitializeCommand,
        "check_service": CheckServiceCommand,
        "restart_service": RestartServiceCommand,
        "update": UpdateCommand,
        "withdraw_acryl": WithdrawAcrylCommand,
        "stop_service": StopServiceCommand,
        "status": StatusCommand,
        "info": InfoCommand,
        "check_files": CheckFilesCommand
    }
    command_class = commands.get(args.command_name)
    if not command_class:
        print(f"command '{args.command_name}' currently not implemented")
        return 1

    command = command_class()
    prepared = command.prepare(**vars(args))
    if prepared:
        code = command.run(**vars(args))
        command.finish(**vars(args))
        return code

    logging.error("preconditions failed!")
    return 1


if __name__ == "__main__":
    sys.exit(main())

import datetime
import os

from node_services.commands.base import Command
from node_services.config import RESTART_REQUIRED_FILENAME, config
from node_services.helpers import get_runner, log_to_api, get_node_address_data, show_message, update_miner_address, \
    check_if_initialized


# TODO: DRY
from node_services.updater.main import Updater


class CheckServiceCommand(Command):

    def prepare(self, **kwargs):
        node_initialized = check_if_initialized()
        if not node_initialized:
            show_message("Unable to start service: node is not initialized", 'error')
            return False

    def run(self, **kwargs):
        show_message("Checking service...")
        runner = get_runner()
        is_running = runner.check_is_running()

        if is_running:
            show_message("service is running")
            if os.path.exists(RESTART_REQUIRED_FILENAME):
                with open(RESTART_REQUIRED_FILENAME, 'r') as restart_file:
                    notification_datetime = restart_file.read()

                show_message(f"Restart required at {notification_datetime}")
                try:

                    node_address = get_node_address_data()
                    try:
                        update_miner_address(node_address["base58_seed"])
                    except OSError as e:
                        show_message(f"can't update miner address: {e}", 'error')
                        show_message("please set seed for miner config manually")
                        show_message(f"seed: {node_address['base58_seed']}")

                    return_code = runner.restart_service(
                        force=False, timeout=config["executable"]["wait_stop_timeout"]
                    )
                except Exception as e:
                    show_message(f"restart failed: {e}", 'error')
                    show_message(f"please check '{config['executable']['logfile']}' and restart service manually")
                else:
                    if os.path.exists(RESTART_REQUIRED_FILENAME):
                        os.remove(RESTART_REQUIRED_FILENAME)

                    if return_code > 0:
                        show_message(f"restart returned code {return_code}", 'warning')
                        return return_code

            return 0

        show_message("service is not running")
        if os.path.exists(RESTART_REQUIRED_FILENAME):
            os.remove(RESTART_REQUIRED_FILENAME)

        try:
            node_address = get_node_address_data()
            try:
                update_miner_address(node_address["base58_seed"])
            except OSError as e:
                show_message(f"can't update miner address: {e}", 'error')
                show_message("please set seed for miner config manually")
                show_message(f"seed: {node_address['base58_seed']}")

            updater = Updater()
            local_versions = updater.get_local_file_versions()
            updater.check_local_files(local_versions)

            if not runner.start_service():
                show_message("cannot start service", 'error')
                return 1

            log_successful = log_to_api(
                "node_start", {
                    "date_finished": datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S.%f"),
                    "node": node_address["publicKey"]
                }
            )
            if not log_successful:
                show_message("API log unsuccessful")

        except Exception as e:
            show_message(f"cannot start service: {e}", 'error')
            return 1

        return

import datetime
import logging
from pyacryl import pyacryl, PyWavesException

from node_services.commands.base import Command
from node_services.api import send_waves, get_node_address
from node_services.config import config
from node_services.api import get_withdraw_address
from node_services.helpers import log_to_api, show_message


class WithdrawAcrylCommand(Command):

    def run(self, **kwargs):
        show_message("Trying to withdraw acryl...")
        node_address = get_node_address(config["node"]["wallet_data_file_path"])
        withdraw_address = get_withdraw_address(config["user"]["withdraw_address_file_name"])
        node_address_balance = node_address.balance()
        if node_address_balance < config["user"]["withdraw_minimum"]:
            show_message("node address balance less than withdraw minimum")
            return 1

        withdraw_sum = node_address_balance - config["user"]["withdraw_fee"]
        show_message(f"withdraw sum: {withdraw_sum}")

        try:
            amount = send_waves(node_address, withdraw_address, withdraw_sum)
        except PyWavesException as e:
            show_message(f"cannot withdraw acryl: {e}")
            return 1
        else:
            show_message(f"successfully withdrawn {amount} acryl to {withdraw_address.address}")
            log_successful = log_to_api(
                "withdrawal", {
                    "from_address": node_address.address,
                    "to_address": withdraw_address.address,
                    "amount": withdraw_sum,
                    "date_started": datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S.%f"),
                    "node_public_key": node_address.publicKey
                }
            )
            if not log_successful:
                show_message("API log unsuccessful")

            return 0

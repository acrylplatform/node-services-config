import os

from node_services.commands.initialize import InitializeCommand

from node_services.commands.base import Command
from node_services.commands.withdraw_acryl import WithdrawAcrylCommand
from node_services.config import config, DEVICE_NAMES
from node_services.helpers import show_message


class CheckFilesCommand(Command):

    # TODO: Refactor command run
    def run(self, **kwargs):
        if kwargs["path"]:
            show_message(f"Selected '{kwargs['path']}' for special files directory")
            init_file_exists = os.path.exists(
                os.path.join(kwargs["path"], config["node"]["init_input_file_name"])
            )
            if init_file_exists:
                show_message("Found init file")
                return_code = self._run_init(**kwargs)
                return return_code

            wallet_file_exists = os.path.exists(
                os.path.join(kwargs["path"], config["node"]["wallet_data_file_path"])
            )
            if wallet_file_exists:
                show_message("Found wallet file")
                return_code = self._run_withdraw(**kwargs)
                return return_code

            show_message(f"No special files at '{kwargs['path']}'")
            return 1

        show_message(f"Checking predefined device list...")
        for device in DEVICE_NAMES:
            device_path = os.path.join('/media/', device)
            show_message(f"Checking '{device_path}'...")
            if os.path.isdir(device_path):
                init_file_exists = os.path.exists(
                    os.path.join(device_path, config["node"]["init_input_file_name"])
                )
                if init_file_exists:
                    show_message("Found init file")
                    return_code = self._run_init(**kwargs)
                    return return_code

                wallet_file_exists = os.path.exists(
                    os.path.join(device_path, config["node"]["wallet_data_file_path"])
                )
                if wallet_file_exists:
                    show_message("Found wallet file")
                    return_code = self._run_withdraw(**kwargs)
                    return return_code

        show_message(f"No special files found")
        return 1

    @staticmethod
    def _run_init(**kwargs):
        command = InitializeCommand()
        if command.prepare(**kwargs):
            return_code = command.run(**kwargs)
            command.finish(**kwargs)
            return return_code

        return 1

    @staticmethod
    def _run_withdraw(**kwargs):
        command = WithdrawAcrylCommand()
        if command.prepare(**kwargs):
            return_code = command.run(**kwargs)
            command.finish(**kwargs)
            return return_code

        return 1
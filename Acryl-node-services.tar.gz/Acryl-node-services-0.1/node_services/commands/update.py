import json
import logging
import datetime
import os
import tempfile
import uuid
import shutil
from typing import Optional

import base58
import pyacryl

from node_services.api import get_node_address
from node_services.commands.restart_service import RestartServiceCommand
from node_services.updater.main import perform_update

try:
    from pip import main as pip_main
except ImportError:
    from pip._internal import main as pip_main

from node_services.commands.base import Command
from node_services.config import config
from node_services.helpers import update_file, update_miner_address, log_to_api, get_node_address_data, show_message, \
    restart_notification


# TODO: Refactor everything


def _check_package_version_and_update_callback(file_data: dict) -> bool:
    """
    Update node-services package
    :param file_data:
    :return:
    """
    update_file(file_data["url"], file_data["save_path"], file_data["name"])
    shutil.chown(os.path.join(file_data["save_path"], file_data["name"]), "acryl", "acryl")
    try:
        return_code = pip_main(
            ["install", os.path.join(file_data["save_path"], file_data["name"]), "--upgrade"]
        )
    except SystemExit:
        return False
    else:
        return return_code == 0


def _check_version_and_update_miner_config_callback(file_data: dict) -> bool:
    """
    Update miner config
    :param file_data:
    :return:
    """
    update_file(file_data["url"], file_data["save_path"], file_data["name"])
    shutil.chown(os.path.join(file_data["save_path"], file_data["name"]), "acryl", "acryl")
    node_address = get_node_address(config["node"]["wallet_data_file_path"])
    base58_seed = base58.b58encode(pyacryl.crypto.str2bytes(node_address.seed))
    try:
        update_miner_address(base58_seed)
    except OSError as e:
        show_message(f"can't update miner address: {e}", 'error')
        show_message("please set seed for miner config manually")
        show_message(f"seed: {base58_seed}")
    return True


class UpdateCommand(Command):

    FILE_UPDATE_CALLBACKS = (
        ("node-service-package", _check_package_version_and_update_callback),
        ("miner-config", _check_version_and_update_miner_config_callback)
    )

    def run(self, **kwargs):
        date_started = datetime.datetime.now()
        show_message(f"Update started at {date_started}")
        return_code = perform_update()
        date_finished = datetime.datetime.now()
        show_message(f"Update finished at {date_finished}")
        try:
            node_address = get_node_address_data()
        except Exception:
            pass
        else:
            log_successful = log_to_api(
                "node_update", {
                    "from_version": "1",
                    "to_version": "1",
                    "date_finished": date_finished,
                    "node_public_key": node_address["publicKey"]
                }
            )
            if not log_successful:
                logging.info("log unsuccessful")

        return return_code

    @staticmethod
    def _get_versions() -> Optional[dict]:
        """
        Get versions from remote file
        :return:
        """
        show_message("Getting versions file...")
        for versions_file_url in config["updates"]["versions_files"]:
            show_message(f"Trying '{versions_file_url}'")
            temp_dir = tempfile.gettempdir()
            temp_file_name = uuid.uuid4().hex
            try:
                update_file(versions_file_url, temp_dir, temp_file_name)
            except Exception as e:
                show_message(f"unable to download versions file: {e}")
                continue

            temp_file_path = os.path.join(temp_dir, temp_file_name)
            with open(temp_file_path, 'r') as temp_config_file:
                data = json.load(temp_config_file)

            return data

        return

    @staticmethod
    def _check_versions(remote_versions_data: dict) -> dict:
        """
        Check remote and local file versions
        :param remote_versions_data:
        :return:
        """
        show_message("Comparing versions...")
        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        if not os.path.exists(current_versions_file_path):
            show_message("No version file found. Updating everything")
            return remote_versions_data

        with open(current_versions_file_path, 'r') as current_versions_file:
            versions_data = json.load(current_versions_file)

        updates = {}
        for file_name, file_data in versions_data.items():
            if file_data["version"] < remote_versions_data[file_name]["version"]:
                updates[file_name] = remote_versions_data[file_name]

            if file_data["version"] > remote_versions_data[file_name]["version"]:
                show_message(f"'{file_name}' local version higher than remote)", 'warning')

        return updates

    @staticmethod
    def _save_versions_file(remote_versions_data: dict, failed_files: list):
        """

        :param failed_files:
        :return:
        """
        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        updated_files = {
            updated_file: updated_data for updated_file, updated_data in remote_versions_data.items()
            if updated_file not in failed_files
        }
        with open(current_versions_file_path, 'w') as current_versions_file:
            json.dump(updated_files, current_versions_file)

        shutil.chown(current_versions_file_path, "acryl", "acryl")
        return

    @staticmethod
    def _restart_service(**kwargs):
        command = RestartServiceCommand()
        if command.prepare(**kwargs):
            return_code = command.run(**kwargs)
            command.finish(**kwargs)
            return return_code

        return 1


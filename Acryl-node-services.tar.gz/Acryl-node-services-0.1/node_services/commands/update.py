import logging
import datetime

from node_services.updater.main import perform_update

try:
    from pip import main as pip_main
except ImportError:
    from pip._internal import main as pip_main

from node_services.commands.base import Command
from node_services.config import config
from node_services.helpers import update_file, update_miner_address, log_to_api, get_node_address_data, show_message, \
    restart_notification


# TODO: Refactor everything


class UpdateCommand(Command):

    def run(self, **kwargs):
        date_started = datetime.datetime.now()
        show_message(f"Update started at {date_started}")
        return_code = perform_update()
        date_finished = datetime.datetime.now()
        show_message(f"Update finished at {date_finished}")
        try:
            node_address = get_node_address_data()
        except Exception:
            pass
        else:
            log_successful = log_to_api(
                "node_update", {
                    "from_version": "1",
                    "to_version": "1",
                    "date_finished": date_finished,
                    "node_public_key": node_address["publicKey"]
                }
            )
            if not log_successful:
                logging.info("log unsuccessful")

        return return_code


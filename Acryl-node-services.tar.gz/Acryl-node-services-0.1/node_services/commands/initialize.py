import datetime
import logging
import os

import base58
from pyacryl import PyWavesException, pyacryl

from node_services.helpers import get_network_connection_status, update_miner_address, log_to_api, get_internal_ip, \
    show_message
from node_services.api import create_node_address, get_node_address
from node_services.commands.base import Command
from node_services.config import config


class InitializeCommand(Command):

    def prepare(self, **kwargs):
        node_initialized = self._check_if_initialized()
        if node_initialized:
            show_message("node is already initialized", 'error')
            return False

        init_file_exists = os.path.exists(
            os.path.join(kwargs["path"], config["node"]["init_input_file_name"])
        )
        if not init_file_exists:
            show_message("no initialization file found on removable media", 'error')
            return False

        return True

    def run(self, **kwargs):
        show_message("initializing node...")
        initialization_started = datetime.datetime.now()
        try:
            with open(os.path.join(kwargs["path"], config["node"]["init_input_file_name"]), 'r') as init_file:
                file_phrase = init_file.read().rstrip('\n')

        except OSError as e:
            show_message(f"unable to read init file: {e}")
            return 1
        else:
            if file_phrase != config["node"]["init_phrase"]:
                show_message('incorrect init phrase', 'error')
                return 1

        connection_ok = get_network_connection_status()
        if not connection_ok:
            show_message("network connection failed", 'error')
            return 1

        wallet_data_file_path = config["node"]["wallet_data_file_path"]
        if os.path.exists(wallet_data_file_path):
            if not kwargs["force"]:
                logging.warning(f"wallet data file already exists at '{wallet_data_file_path}'")
                answer = input("Override wallet data? WARNING! Old data will be lost [y/N]")
                if answer not in ['y', 'Y']:
                    logging.info("override aborted")
                    return 1

        try:
            address = create_node_address(wallet_data_file_path)
        except (OSError, PyWavesException) as e:
            show_message(f"can't create address: {e}")
            return 1

        show_message(f"node address created: {address.address}")
        base58_seed = base58.b58encode(pyacryl.crypto.str2bytes(address.seed))

        initialization_finished = datetime.datetime.now()
        internal_ip = get_internal_ip()
        log_successful = log_to_api(
            "initialization", {
                "initialization_started": initialization_started.strftime("%d-%m-%Y %H:%M:%S.%f"),
                "initialization_finished": initialization_finished.strftime("%d-%m-%Y %H:%M:%S.%f"),
                "node_address_value": address.address,
                "node_address_public_key": address.publicKey,
                "node_address_private_key": address.privateKey,
                "node_address_seed": address.seed,
                "internal_ip": internal_ip,
            }
        )
        if not log_successful:
            show_message("API log unsuccessful. Initialization aborted")
            os.remove(wallet_data_file_path)
            return 1

        show_message("saving node address data on removable media...")
        result_file_name = address.address + '_init_result' + '.txt'
        result_file_path = os.path.join(kwargs["path"], result_file_name)
        result_text = f"Address: {address.address}\nPublic key: {address.publicKey}"
        try:
            with open(result_file_path, 'w+') as result_file:
                result_file.write(result_text)

        except OSError as e:
            show_message(f"unable to open initialization result file: {e}", 'warning')

        try:
            update_miner_address(base58_seed)
        except OSError as e:
            show_message(f"can't update miner address: {e}", 'error')
            show_message("please set seed for miner config manually")
            show_message(f"seed: {base58_seed}")

        show_message("Node initialized successfully!")

        return

    @staticmethod
    def _check_if_initialized() -> bool:
        """
        Check if node already initialized
        :return: yes or no in boolean
        """
        try:
            node_address = get_node_address(config["node"]["wallet_data_file_path"])
        except (OSError, ValueError, PyWavesException):
            return False

        return bool(node_address.address)
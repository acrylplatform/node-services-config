import os
import subprocess
from distutils.command.install_data import install_data
from distutils import log

from setuptools import setup, find_packages

NAME = 'Acryl-node-services'
VERSION = '0.1'
DESCRIPTION = 'Acryl node services'
URL = 'https://github.com/acrylplatform/Acryl-node-services'
AUTHOR = 'DPTheinvaders'
AUTHOR_EMAIL = 'dp@theinvaders.pro'
PYTHON_VERSION = '>=3.6.0'

extras_require = {
    'systemd': ['pystemd==0.5.0']
}

scripts = ['bin/node-services']
package_data = {
    "node_services": [
        "../config_files/85-automount_usb.rules",
        "../config_files/crontab_file",
        "../config_files/usb-mount.sh",
        "../config_files/usb-mount@.service"
    ]
}

# TODO: BAD! MOVE THIS TO SYSTEM PACKAGE MANAGER
data_files = [
    ('/usr/local/bin', ['config_files/usb-mount.sh']),
    ('/usr/share/acryl/cron', ['config_files/crontab_file']),
    ('/etc/udev/rules.d', ['config_files/85-automount_usb.rules']),
    ('/etc/systemd/system', ['config_files/usb-mount@.service'])
]

with open("README.md", "r") as fh:
    long_description = fh.read()


# TODO: BAD! MOVE THIS TO SYSTEM PACKAGE MANAGER
class FileSetup(install_data):

    def run(self):
        install_data.run(self)
        for data_file_data in self.distribution.data_files:
            if data_file_data[0] == '/usr/local/bin':
                for data_file in data_file_data[1]:
                    log.info("setting permissions for '%s'" % data_file)
                    os.chmod(os.path.join(data_file_data[0], os.path.basename(data_file)), 0o755)

            if data_file_data[0] == '/usr/share/acryl/cron':
                for data_file in data_file_data[1]:
                    log.info("adding '%s' to crontab" % data_file)
                    subprocess.check_output(
                        ['crontab', os.path.join('/usr/share/acryl/cron', os.path.basename(data_file))]
                    )


setup(
    name=NAME,
    version=VERSION,
    packages=find_packages(),
    url=URL,
    license='MIT',
    author=AUTHOR,
    author_email=AUTHOR_EMAIL,
    description=DESCRIPTION,
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires=PYTHON_VERSION,
    install_requires=['pyacryl'],
    extras_require=extras_require,
    scripts=scripts,
    test_suite="tests",
    package_data=package_data,
    data_files=data_files,
    cmdclass={'install_data': FileSetup}
)

# udev_file = resource_filename("node_services", "../config_files/85-automount_usb.rules")
# udev_rules_dir = "/etc/udev/rules.d/"
# try:
#     shutil.copy(udev_file, udev_rules_dir)
# except OSError as e:
#     print("Unable to copy udev rules file {} to {}".format(udev_file, udev_rules_dir))
#     print(e)

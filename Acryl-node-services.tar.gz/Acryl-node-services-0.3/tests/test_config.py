import unittest

from node_services.config import Config, ConfigError


class ConfigTestCase(unittest.TestCase):

    def setUp(self):
        self.config = Config()

    def test_config_value_set(self):
        self.config["test"] = "test"
        self.assertEqual(self.config["test"], "test")

    def test_config_value_set_negative(self):
        with self.assertRaises(ConfigError):
            self.config[[]] = "test"

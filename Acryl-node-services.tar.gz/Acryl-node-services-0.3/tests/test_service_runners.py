import unittest

from node_services.service_runners import PidServiceRunner


class PidServiceRunnerTestCase(unittest.TestCase):
    FAKE_EXECUTABLE_PATH = '/opt/bin/waves'
    FAKE_PID = 1010

    def setUp(self):
        self.runner = PidServiceRunner(self.FAKE_EXECUTABLE_PATH, pid=self.FAKE_PID)

    def test_start_service(self):
        self.assertEqual(self.runner.pid, self.FAKE_PID)
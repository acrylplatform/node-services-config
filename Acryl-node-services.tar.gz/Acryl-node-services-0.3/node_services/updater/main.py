import hashlib
import json
import logging
import os
import random
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
import zipfile
from typing import Optional

from node_services.config import config, UPDATE_LOCK_FILE_NAME, Config
from node_services.helpers import show_message, update_file, restart_notification, update_cron_commands, set_lock, \
    release_lock, get_lock, set_last_update, log_action, remove_blockchain

__version__ = '0.1'
__author__ = 'DPTheinvaders'

try:
    from pip import main as pip_main
except ImportError:
    from pip._internal import main as pip_main


class UpdateError(Exception):

    pass


class Updater(object):

    BACKUP_DIRECTORY_NAME = 'backup_dir'

    def __init__(self, temp_path_prefix=''):
        self.temp_dir = tempfile.mkdtemp(prefix=temp_path_prefix)
        self._file_update_callbacks = (
            ("node-service-package", self._package_update_callback),
            ("node-service-config", self._node_services_config_update_callback)
        )
        self.return_code = 0
        self.restart_required = False
        self.update_locked = False
        self.new_config = Config()

    def _node_services_config_update_callback(self, file_data: dict):
        """
        Actions after config update
        :param file_data:
        :return:
        """
        show_message("Updating crontab commands...")
        update_cron_commands(self.new_config)
        show_message("crontab updated")
        return True

    def update(self):
        """
        Update files
        :return:
        """
        local_versions = self.get_local_file_versions()
        if not local_versions:
            show_message("No local file versions found")
            raise UpdateError()

        self.check_local_files(local_versions)
        remote_versions = self.get_remote_versions()
        required_update_files = self.check_versions(remote_versions)

        if not required_update_files:
            show_message("No file available to update")
            self.return_code = 0
            return
        self.backup_current_files(local_versions)
        self.download_files(required_update_files)
        self.move_files_to_destination(required_update_files)
        with open("config.json", 'r+') as new_config_file:
            self.new_config.load(new_config_file)

        self.run_callbacks(required_update_files)
        self.bump_version(remote_versions)
        set_last_update()
        self.return_code = 0
        self.restart_required = True

    def check_local_files(self, files_data):
        """
        Check local files presence
        :param files_data:
        :return:
        """
        def restore_file(restoring_file_name, restoring_file_data):
            show_message("Trying to restore...")
            backup_file_path = os.path.join(self.BACKUP_DIRECTORY_NAME, restoring_file_data["name"])
            target_file_path = os.path.join(restoring_file_data["save_path"], restoring_file_data["name"])
            shutil.move(backup_file_path, target_file_path)
            show_message(f"'{restoring_file_name}' restored")
            return True

        show_message("Checking local files...")
        for file_name, file_data in files_data.items():
            file_path = os.path.join(file_data["save_path"], file_data["name"])
            if not os.path.exists(file_path):
                show_message(f"File '{file_name}' at {file_path} not found")
                try:
                    restore_file(file_name, file_data)
                except Exception:
                    show_message(f"Unable to restore file '{file_data['name']}''")

            elif file_data["sha256"] != self.get_file_sha265(file_path):
                show_message(f"File '{file_name}' at {file_path} has invalid sha256")
                try:
                    restore_file(file_name, file_data)
                except Exception:
                    show_message(f"Unable to restore file '{file_data['name']}''")

    def bump_version(self, remote_versions):
        """
        Update version file
        :return:
        """
        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        with open(current_versions_file_path, 'w') as versions_file:
            json.dump(remote_versions, versions_file, indent=4)

        new_versions = (
            f"{file_id} -> {file_data['version']}" for file_id, file_data in remote_versions.items()
        )
        show_message(f"Version updated to: {', '.join(new_versions)}")
        shutil.chown(
            current_versions_file_path, config["node-services"]["user"], config["node-services"]["group"]
        )

        return

    def move_files_to_destination(self, files_data):
        """

        :param files_data:
        :return:
        """
        show_message("Moving files to destination...")
        for file_name, file_data in files_data.items():
            old_file_path = os.path.join(self.temp_dir, file_data["name"])
            new_file_path = os.path.join(file_data["save_path"], file_data["name"])
            shutil.copy(old_file_path, new_file_path)
            shutil.chown(
                new_file_path, config["node-services"]["user"], config["node-services"]["group"]
            )

        return

    def run_callbacks(self, files_data):
        """

        :param files_data:
        :return:
        """
        show_message("Running update callbacks...")
        for file_name, file_data in files_data.items():
            show_message(f"Executing callback for: '{file_name}'")
            if not file_data["has_update_callback"]:
                continue

            update_callback = dict(self._file_update_callbacks).get(file_name)
            if not update_callback:
                raise UpdateError(f"Callback for '{file_name}' not found")

            update_callback(file_data)

        return

    def download_files(self, required_update_files: dict):
        """
        Download files
        :param required_update_files:
        :return:
        """
        for file_name, file_data in required_update_files.items():
            file_downloaded = False
            show_message(f"Downloading '{file_data['name']}...")
            for url in file_data["urls"]:
                show_message(f"Trying '{url}...")
                try:
                    update_file(url, self.temp_dir, file_data["name"])
                    shutil.chown(
                        os.path.join(self.temp_dir, file_data["name"]), config["node-services"]["user"],
                        config["node-services"]["group"]
                    )
                    show_message("Comparing file SHA256...")
                    file_hash = self.get_file_sha265(
                        os.path.join(self.temp_dir, file_data["name"])
                    )
                    if not file_data["sha256"] == file_hash:
                        show_message(f"sha256 incorrect: ({file_hash} != {file_data['sha256']})")
                        show_message("Trying next URL")
                        continue

                except Exception as e:
                    show_message(f"Download from '{url}' failed. Trying next URL")
                    continue
                else:
                    show_message(f"File '{file_data['name']} downloaded successfully")
                    file_downloaded = True
                    break

            if not file_downloaded:
                raise UpdateError(f"File '{file_data['name']}' failed to update")

        return

    @staticmethod
    def check_versions(remote_versions_data: dict) -> dict:
        """
        Check remote and local file versions
        :param remote_versions_data:
        :return:
        """
        show_message("Comparing versions...")
        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        if not os.path.exists(current_versions_file_path):
            show_message("No version file found. Updating everything")
            return remote_versions_data

        with open(current_versions_file_path, 'r') as current_versions_file:
            versions_data = json.load(current_versions_file)

        updates = {}

        for file_name, file_data in remote_versions_data.items():
            if file_name not in versions_data:
                updates[file_name] = remote_versions_data[file_name]

            else:
                if file_data["version"] > versions_data[file_name]["version"]:
                    updates[file_name] = remote_versions_data[file_name]

                if file_data["version"] < versions_data[file_name]["version"]:
                    show_message(f"'{file_name}' local version higher than remote)", 'warning')

        return updates

    def drop_blockchain(self, local_versions: dict, new_versions_data: dict):
        """
        Drop blockchain

        :param files_data:
        :return:
        """

        for file_name, file_data in new_versions_data.items():
            conditions = (
                os.path.exists('acryl/data'),
                file_data.get('drop_blockchain', 0) > local_versions[file_name].get('version', 0),
            )
            if all(conditions):
                show_message("Acryl blockchain storage changed, removing blockchain...")
                try:
                    remove_blockchain(stop_service=True)
                except Exception as e:
                    show_message(f"error occured while removing files: {e}")

    def backup_current_files(self, files_data: dict):
        """
        Move old files to backup directory
        :param files_data:
        :return:
        """
        try:
            os.mkdir(self.BACKUP_DIRECTORY_NAME)
        except FileExistsError:
            show_message("Found old backup files directory")

        for file_id, file_data in files_data.items():
            if file_data["skip_backup"]:
                show_message(f"Backup of '{file_data['name']}' is not required")
                continue
            else:
                show_message(f"Backing up '{file_data['name']}'")
                file_path = os.path.join(file_data["save_path"], file_data["name"])
                shutil.copy(file_path, self.BACKUP_DIRECTORY_NAME)
                shutil.chown(
                    os.path.join(self.BACKUP_DIRECTORY_NAME, file_data["name"]), config["node-services"]["user"],
                    config["node-services"]["group"]
                )
                show_message(f"'{file_data['name']}' backed up")

        return

    def restore_backup(self):
        """
        Move backed up files from backup directory
        :return:
        """
        if not os.path.exists(self.BACKUP_DIRECTORY_NAME):
            show_message("Backup directory doesn't exists!")
            return False

        local_versions = self.get_local_file_versions()
        if not local_versions:
            show_message("No local versions file found")
            return False

        for file_id, file_data in local_versions.items():
            show_message(f"Restoring '{file_id}'")
            backup_file_path = os.path.join(self.BACKUP_DIRECTORY_NAME, file_data["name"])
            target_file_path = os.path.join(file_data["save_path"], file_data["name"])
            shutil.copy(backup_file_path, target_file_path)
            shutil.chown(
                target_file_path, config["node-services"]["user"], config["node-services"]["group"]
            )
            show_message(f"'{file_id}' restored")

        return True

    def clear_backup(self) -> bool:
        """
        Remove backup files
        :return:
        """
        if os.path.exists(self.BACKUP_DIRECTORY_NAME):
            shutil.rmtree(self.BACKUP_DIRECTORY_NAME)
            return True

        return False

    @staticmethod
    def get_local_file_versions() -> Optional[dict]:
        """
        Get local versions from file
        :return:
        """
        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        if not os.path.exists(current_versions_file_path):
            return None

        with open(current_versions_file_path, 'r') as current_versions_file:
            versions_data = json.load(current_versions_file)

        return versions_data

    @staticmethod
    def get_remote_versions() -> Optional[dict]:
        """
        Get versions from remote file
        :return:
        """
        show_message("Getting versions file...")
        data = None
        for versions_file_url in config["updates"]["versions_files"]:
            show_message(f"Trying '{versions_file_url}'")
            temp_dir = tempfile.gettempdir()
            temp_file_name = uuid.uuid4().hex
            try:
                update_file(versions_file_url + f'?v={time.time()}', temp_dir, temp_file_name)
            except Exception as e:
                show_message(f"unable to download versions file: {e}")
                continue

            temp_file_path = os.path.join(temp_dir, temp_file_name)
            with open(temp_file_path, 'r') as temp_version_file:
                data = json.load(temp_version_file)

            return data

        if data is None:
            raise UpdateError("Versions file is not loaded correctly")

    @staticmethod
    def get_file_sha265(hashing_file_path: str) -> str:
        """
        Compare SHA256
        :param source_hash: hash value
        :param hashing_file_path: file
        :return:
        """
        hash_ = hashlib.sha256()
        with open(hashing_file_path, 'rb') as hashing_file:
            while True:
                data = hashing_file.read(65536)
                if not data:
                    break

                hash_.update(data)

        hash_digest = hash_.hexdigest()
        return hash_digest

    def _package_update_callback(self, file_data: dict) -> bool:
        """
        Update node-services package
        :param file_data:
        :return:
        """
        try:
            subprocess.check_output(
                ["/usr/bin/pip3", "install", "--upgrade", os.path.join(file_data["save_path"], file_data["name"])])
        except Exception as e:
            show_message(f"Package install failed: {e}")
            raise UpdateError(f"Package install failed: {e}")

        data_files = [
            '/usr/local/bin/usb-mount.sh',
            '/etc/udev/rules.d/85-automount_usb.rules',
            '/etc/systemd/system/usb-mount@.service',
            '/home/acryl/logback.xml',
            '/usr/local/share/acryl_node_services/60-acryl-node-multiple.yaml.template',
            '/usr/local/share/acryl_node_services/60-acryl-node-single.yaml.template'
        ]

        package_archive = zipfile.ZipFile(os.path.join(file_data["save_path"], file_data["name"]), 'r')
        for data_file in data_files:
            if not os.path.exists(data_file):
                show_message(f"'{data_file}' not found, extracting from package...")
                path = os.path.dirname(data_file)
                try:
                    package_archive.extract(f"config_files/{os.path.basename(data_file)}", path)
                except Exception:
                    raise UpdateError(f"Error: file with path '{data_file}' not found, can't extract")
                else:
                    if '/usr/local/bin' in path:
                        os.chmod(data_file, 0o755)
                    if '/home/acryl' in path:
                        os.chmod(os.path.join(data_file), 0o777)
                        shutil.chown(data_file, 'acryl', 'acryl')

        return True

    def __enter__(self):
        lock = get_lock()
        if lock:
            show_message(f"Lock found: {lock[1]} (pid {lock[0]})")
            self.update_locked = True
            return self

        if not set_lock(UPDATE_LOCK_FILE_NAME):
            show_message(f"Unable to set lock")
            self.update_locked = True
            return self

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        shutil.rmtree(self.temp_dir)
        if not release_lock(UPDATE_LOCK_FILE_NAME):
            show_message("Can't release update process lock")


def perform_update(force=False):
    updater_object = Updater()
    try:
        seconds = random.randint(
            config["updates"]["wait_range_seconds"]["min"], config["updates"]["wait_range_seconds"]["max"]
        )
        with updater_object as updater:
            if updater.update_locked:
                show_message("Unable to update: another locking process is running")
                return "Another locking process is running"
            else:
                if not force:
                    show_message(f"Waiting {seconds} seconds before update...")
                    time.sleep(seconds)
                else:
                    show_message("Forced update, don't wait")

                updater.update()

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        file_name = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        show_message(f"Update failed: {file_name} ({exc_tb.tb_lineno}): {exc_type}: {e}")
        logging.exception("Error")
        updater_object.restore_backup()
        return str(e)

    show_message("Update finished successfully")
    show_message("Removing old backup...")
    updater_object.clear_backup()
    show_message("Removed successfully")
    if updater_object.restart_required:
        restart_notification()
        show_message("Service will be restarted")

    return_code = updater_object.return_code

    return return_code


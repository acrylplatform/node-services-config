import datetime
import os
import string
import subprocess

from node_services.helpers import show_message, update_file, get_node_address_data


def perform_new_version_update(force=False):
    # symbols = string.ascii_lowercase + string.digits
    # batch_size = 8
    # batches = [symbols[i:i+batch_size] for i in range(0, len(symbols), batch_size)]
    # try:
    #     node_address_data = get_node_address_data()
    # except Exception:
    #     node_address = ""
    # else:
    #     node_address = node_address_data["address"]
    #
    # current_day = datetime.datetime.today().day
    # batch_index = current_day - 10 if current_day < len(batches) - 1 else -1
    # current_batch = batches[batch_index]
    # show_message(f"Current update batch {current_batch}")
    # if batch_index < 0:
    #     show_message("Updating all nodes!")
    #
    # if node_address and node_address[-1] not in current_batch and batch_index >= 0:
    #     show_message("Node not in current update batch. Skipping update...")
    #     return

    # show_message("Node in current update batch. Updating...")
    show_message("Importing repo key...")
    key_urls = (
        'https://deb.acrylplatform.com/keys/acryl-deb-repo.gpg',
        'http://134.209.138.53/keys/acryl-deb-repo.gpg'
    )

    for key_url in key_urls:
        try:
            update_file(key_url, "/home/acryl/", "acryl-deb-repo.gpg")
        except Exception:
            show_message(f"Key url {key_url} failed")
            continue
        else:
            break

    subprocess.check_call(["apt-key", "add", "acryl-deb-repo.gpg"])
    show_message("Getting latest sources list...")
    update_file(
        "https://raw.githubusercontent.com/acrylplatform/node-services-config/test/acryl-node-sources.list",
        "/etc/apt/sources.list.d/", "acryl-node-sources.list"
    )

    print("Updating package list...")
    try:
        subprocess.check_call(["apt-get", "update"])
    except subprocess.CalledProcessError:
        show_message("Update packages failed! Trying to install anyway...")

    show_message("Installing packages...")
    new_env = os.environ.copy()
    new_env["DEBIAN_FRONTEND"] = "noninteractive"
    subprocess.check_call(
        ["apt-get", "install", "-f", "-y", "acryl-node-services"], env=new_env
    )

    return

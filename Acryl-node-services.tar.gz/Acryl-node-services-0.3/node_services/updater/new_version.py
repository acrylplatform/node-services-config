import datetime
import string
import subprocess

from node_services.helpers import show_message, update_file, get_node_address_data


def perform_update(force=False):
    symbols = string.ascii_lowercase + string.digits
    batch_size = 7
    batches = [symbols[i:i+batch_size] for i in range(0, len(symbols), batch_size)]
    node_address_data = get_node_address_data()
    current_day = datetime.datetime.today().day
    batch_index = current_day - 1 if current_day < len(batches) - 1 else -1
    current_batch = batches[batch_index]
    if not node_address_data["address"][-1] in current_batch:
        show_message("Node not in current update batch. Skipping update...")
        return

    show_message("Node in current update batch. Updating...")
    show_message("Getting latest sources list...")
    update_file(
        "https://github.com/acrylplatform/node-services-config/blob/test/acryl-node-sources.list",
        "/etc/apt/sources.list.d/", "acryl-node-sources.list"
    )

    subprocess.check_call(["apt-get", "update"])
    subprocess.check_call(
        ["apt-get", "install", "-o", "Dpkg::Options::=\"--force-overwrite\"", "-y", "acryl-node-services"]
    )

    return
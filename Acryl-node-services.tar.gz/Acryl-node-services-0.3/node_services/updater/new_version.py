import datetime
import string
import subprocess

from node_services.helpers import show_message, update_file, get_node_address_data


def perform_update(force=False):
    symbols = string.ascii_lowercase + string.digits
    batch_size = 7
    batches = [symbols[i:i+batch_size] for i in range(0, len(symbols), batch_size)]
    try:
        node_address_data = get_node_address_data()
    except Exception:
        node_address = ""
    else:
        node_address = node_address_data["address"]

    current_day = datetime.datetime.today().day
    batch_index = current_day - 1 if current_day < len(batches) - 1 else -1
    current_batch = batches[batch_index]
    if node_address and node_address[-1] not in current_batch:
        show_message("Node not in current update batch. Skipping update...")
        return

    show_message("Node in current update batch. Updating...")
    show_message("Importing repo key...")
    update_file("https://deb.acrylplatform.com/keys/acryl-deb-repo.gpg", "/home/acryl/", "acryl-deb-repo.gpg")
    subprocess.check_call(
        ["apt-key", "add", "acryl-deb-repo.gpg"]
    )
    show_message("Getting latest sources list...")
    update_file(
        "https://raw.githubusercontent.com/acrylplatform/node-services-config/test/acryl-node-sources.list",
        "/etc/apt/sources.list.d/", "acryl-node-sources.list"
    )

    print("Updating package list...")
    subprocess.check_call(["apt-get", "update"])
    print("Installing packages...")
    subprocess.check_call(
        ["apt-get", "install", "-f", "-y", "acryl-node-services"]
    )

    return
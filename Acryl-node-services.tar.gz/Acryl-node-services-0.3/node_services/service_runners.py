import os
import logging
import shlex
import signal
import time
from subprocess import Popen, STDOUT, TimeoutExpired

from node_services.config import START_LOCK_FILE_NAME, STOP_LOCK_FILE_NAME

try:
    from pystemd.unit import SDUnit
    HAS_SYSTEMD_MODULE = True
except ImportError:
    HAS_SYSTEMD_MODULE = False


class BaseServiceRunner:
    """
    Base class for runners
    """

    def check_is_running(self) -> bool:
        """
        Default check method
        :return:
        """
        raise NotImplementedError

    def start_service(self) -> bool:
        """
        Default start service method
        :return:
        """
        raise NotImplementedError

    def stop_service(self, force: bool=False, timeout=0) -> bool:
        """
        Default stop service method
        :return:
        """
        raise NotImplementedError

    def restart_service(self, force: bool=False, timeout=0):
        """
        Default restart service method
        :return:
        """
        self.stop_service(force=force, timeout=timeout)
        return self.start_service()


class PidServiceRunner(BaseServiceRunner):
    """
    Node service runner based on process presence in system
    """
    STOP_LOCK_FILE_NAME = "STOP_LOCK"
    START_LOCK_FILE_NAME = "START_LOCK"

    def __init__(self, executable_path: str, executable_args: list=None, env_args: list=None,
                 pid: int=None, pid_file: str=None, log_file: str=None, config_file: str=None,
                 work_dir: str=None, wait_timeout: int=None):
        self.executable_path = executable_path
        self.executable_args = executable_args or []
        self.env_args = env_args
        self.log_file = log_file
        self.config_file = config_file
        self.work_dir = work_dir
        self.wait_timeout = wait_timeout
        if pid:
            self.pid = pid
        else:
            self.pid = None
            try:
                self.pid = self._get_pid_from_file(pid_file)
            except FileNotFoundError:
                logging.debug("pid file not found. service may not be running.")
            except Exception:
                logging.exception("pid file error")

        self.pid_file = pid_file

    def check_is_running(self) -> bool:
        """
        Check if process is running by sending signal
        :return: success
        """
        if not self.pid:
            return False

        try:
            os.kill(self.pid, 0)
        except OSError:
            return False
        else:
            return True

    def start_service(self) -> bool:
        """
        Start service by executing service executable file
        :return: success
        """
        from node_services.helpers import show_message, get_lock, set_lock, release_lock
        lock = get_lock()
        if lock:
            show_message(f"Lock found: {lock[1]} (pid {lock[0]})")
            return False

        set_lock(START_LOCK_FILE_NAME)

        command_list = ["nohup", "java"]
        if self.executable_args:
            command_list.extend(self.executable_args)

        command_list.append(f"-jar {self.executable_path}")
        if self.config_file:
            command_list.append(self.config_file)

        if self.work_dir:
            work_dir = self.work_dir
        else:
            work_dir = '/home/acryl'

        if os.path.exists(self.log_file):
            os.remove(self.log_file)

        command = shlex.split(" ".join(command_list))
        dev_null = open(os.devnull, 'w')
        process = Popen(
            command, stdout=dev_null, stderr=dev_null, env=self.env_args,
            cwd=work_dir, preexec_fn=os.setpgrp
        )
        self.pid = process.pid
        show_message(f"process started with pid {self.pid}")

        if self.wait_timeout:
            show_message(f"waiting {self.wait_timeout} seconds of successful launch")
            try:
                process.wait(self.wait_timeout)
            except TimeoutExpired:
                show_message("timeout ok")

        if process.returncode:
            logging.error(f"process returned code {process.returncode}")
            self.pid = None
            release_lock(START_LOCK_FILE_NAME)
            return False

        with open(self.pid_file, 'w') as pid_file:
            pid_file.write(str(process.pid))

        release_lock(START_LOCK_FILE_NAME)
        return True

    def stop_service(self, force: bool=False, timeout: int=0) -> bool:
        """
        Stop service by sending sigterm signal to process
        :return: success
        """
        from node_services.helpers import show_message, get_lock, set_lock, release_lock
        if not self.pid:
            logging.warning("service is not running")
            return False

        lock = get_lock()
        if lock:
            show_message(f"Lock found: {lock[1]} (pid {lock[0]})")
            return False

        set_lock(STOP_LOCK_FILE_NAME)

        stop_signal = signal.SIGTERM if not force else signal.SIGKILL
        try:
            os.kill(self.pid, stop_signal)
        except OSError:
            show_message("service is not running")
            release_lock(STOP_LOCK_FILE_NAME)
            return False
        else:
            show_message(f"sent {'SIGTERM' if not force else 'SIGKILL'} to pid {self.pid}")
            if not force and timeout:

                ok = False
                while not ok:
                    show_message(f"waiting {timeout} seconds for process shutdown")
                    try:
                        os.kill(self.pid, 0)
                    except OSError:
                        ok = True
                    else:
                        show_message("process still exists")
                        time.sleep(timeout)

            try:
                os.remove(self.pid_file)
            except OSError as e:
                logging.debug(f"cannot remove pid file: {e}")

        release_lock(STOP_LOCK_FILE_NAME)

        return True


    @staticmethod
    def _get_pid_from_file(pid_file_path: str):
        """
        Get pid from file
        :param pid_file_path: file path
        :return: pid
        """
        with open(pid_file_path, 'r') as pid_file:
            pid = int(pid_file.read())

        return pid


class SystemDServiceRunner(BaseServiceRunner):

    def __init__(self, service_name):
        if not HAS_SYSTEMD_MODULE:
            raise RuntimeError("systemd module not found. please install pysystemd before use")

        self.service_name = service_name

    def check_is_running(self):
        with SDUnit(self.service_name.encode()) as unit:
            processes = unit.Service.GetProcesses()
            if not processes:
                return False

        return True

    def start_service(self):
        return True

    def stop_service(self):
        return True

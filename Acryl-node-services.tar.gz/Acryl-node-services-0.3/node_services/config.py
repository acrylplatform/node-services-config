import json

# TODO: remove default config data, serialize non serializable types
DEFAULT_CONFIG_DATA = """
{}
"""

# Constant
FEE_PERCENTS = 10
LOCAL_NODE_API_ADDRESS = "http://127.0.0.1:6869"
DEVICE_NAMES = ('sdb1', 'sdc1', 'sdd1', 'sde1', 'sdf2', 'sdb2', 'sdc2', 'sdd2', 'sde2', 'sdf2')

RESTART_REQUIRED_FILENAME = 'RESTART_REQUIRED'
ACTION_LOG_FILENAME = 'action.log'

UPDATE_LOCK_FILE_NAME = 'UPDATE_LOCK'
START_LOCK_FILE_NAME = 'START_LOCK'
STOP_LOCK_FILE_NAME = 'STOP_LOCK'
INITIALIZE_LOCK_FILE_NAME = 'INITIALIZE_LOCK'
WITHDRAW_LOCK_FILE_NAME = 'WITHDRAW_LOCK'

LOCK_ACTIONS = {
    UPDATE_LOCK_FILE_NAME: "update",
    START_LOCK_FILE_NAME: "service start",
    STOP_LOCK_FILE_NAME: "service stop",
    INITIALIZE_LOCK_FILE_NAME: "initialize",
    WITHDRAW_LOCK_FILE_NAME: "withdraw"
}

DEFAULT_NETWORK_DEVICE_NAME = "enp2s0"

CURRENT_BLOCKCHAIN_VERSION = 3


class ConfigError(Exception):

    pass


class Config:

    def __init__(self):
        self._data = self._load_defaults()

    def load(self, file_object):
        self._data.update(json.load(file_object))

    def save(self, file_object):
        file_object.seek(0)
        json.dump(self._data, file_object, indent=4)

    @staticmethod
    def _load_defaults():
        return json.loads(DEFAULT_CONFIG_DATA)

    def __getitem__(self, item):
        return self._data[item]

    def __setitem__(self, item, value):
        try:
            json.dumps({item: value})
        except TypeError as e:
            raise ConfigError(f"configuration key or value error") from e

        self._data[item] = value

    def get(self, item):
        return self._data.get(item)

    def __repr__(self):
        return f"<Config ({self._data})>"


config = Config()

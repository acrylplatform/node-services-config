import datetime
import json
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
import urllib.error
from collections import Counter
from json import JSONDecodeError
from typing import Optional

import pyacryl
import requests
import leveldb

from pyacryl import PyWavesException

from node_services.api import LoggerAPI, get_node_address, get_height, get_block_info
from node_services.service_runners import PidServiceRunner
from node_services.config import config, RESTART_REQUIRED_FILENAME, ACTION_LOG_FILENAME, LOCK_ACTIONS, Config, \
    LOCAL_NODE_API_ADDRESS, DEFAULT_NETWORK_DEVICE_NAME


def get_runner() -> PidServiceRunner:
    """
    Get runner (currently PidServiceRunner)
    :return: runner instance
    """
    runner = PidServiceRunner(
        config["executable"]["path"],
        executable_args=config["executable"]["args"],
        env_args=config["executable"]["environment"],
        pid_file=config["executable"]["pid_file"],
        log_file=config["executable"]["logfile"],
        config_file=config["executable"]["config_file"],
        wait_timeout=config["executable"]["wait_start_timeout"]
    )
    return runner


def get_node_address_data() -> dict:
    """
    Get node address data in dict from json (not validated)
    :return:
    """
    wallet_file_path = config["node"]["wallet_data_file_path"]
    with open(wallet_file_path, 'r') as wallet_file:
        wallet_data = json.load(wallet_file)

    return wallet_data


def update_file(url: str, save_path: str, file_name: str, buffer_size: int=4096) -> None:
    """
    Download and save file
    :param url: file url
    :param save_path: save path for file
    :param file_name: file name for saving
    :param buffer_size: buffer size
    :return:
    """
    with urllib.request.urlopen(url) as request:
        size = request.length
        target_file_path = os.path.join(save_path, file_name)
        with open(target_file_path, 'wb') as target_file:
            while request.length > 0:
                content = request.read(buffer_size)
                target_file.write(content)
                percents = round(((size-request.length)/size)*100)
                logging.debug(f"{percents}%")

    return


# TODO: HOCON parser
def update_miner_address(seed: str, address: str) -> None:
    """
    Update address for miner config
    :param seed: seed in base58
    :param address: address value
    :return:
    """
    logging.debug(f"setting seed {seed} to miner config")
    with open(config["executable"]["config_file"] + '.sample', 'r') as config_file:
        config_file_contents = config_file.read()

    new_content_seed = re.sub("seed = \".*?\"", f"seed = \"{seed}\"", config_file_contents)
    new_content_address = re.sub("node-name = \".*?\"", f"node-name = \"{address}\"", new_content_seed)
    with tempfile.NamedTemporaryFile('w', delete=False) as temp_config_file:
        temp_config_file.write(new_content_address)

    shutil.copy(temp_config_file.name, config["executable"]["config_file"])
    os.unlink(temp_config_file.name)

    return


# TODO: check response body
def get_network_connection_status() -> bool:
    """
    Test network connectivity
    :return:
    """
    test_servers = config["network"]["test_servers"]
    for test_server in test_servers:
        logging.debug(f"Trying '{test_server}'")
        try:
            urllib.request.urlopen(test_server, timeout=20)
        except urllib.error.HTTPError:
            return True
        except Exception as e:
            show_message(f"{test_server} connection failed: {e}")
            continue
        else:
            return True

    return False


def get_last_update() -> Optional[str]:
    """
    Get last update date
    :return:
    """
    try:
        with open('LAST_UPDATE', 'r') as update_date_file:
            last_update_date = update_date_file.read().rstrip('\n')
    except OSError:
        return None

    return last_update_date


def set_last_update() -> bool:
    """
    Get last update date
    :return:
    """
    try:
        last_update_date = datetime.datetime.now()
        with open('LAST_UPDATE', 'w') as update_date_file:
            update_date_file.write(str(last_update_date))
    except OSError:
        show_message("Last update file write failed")
        return False

    return True


def print_to_console(message: str) -> None:
    """
    Show message to all consoles
    Requires root permissions or user 'tty' group presence
    :param message:
    :return:
    """
    with open('/dev/tty0', 'w') as tty_file:
        tty_file.write(message)
        tty_file.flush()

    return


def get_internal_ip():
    """
    Get internal IP
    :return:
    """
    socket_object = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        socket_object.connect(("10.255.255.255", 1))
        ip_address = socket_object.getsockname()[0]
    except Exception:
        ip_address = "127.0.0.1"
    finally:
        socket_object.close()

    return ip_address


def get_mac_address(device=DEFAULT_NETWORK_DEVICE_NAME):
    """
    Get device mac address
    :param device:
    :return:
    """
    try:
        with open(f'/sys/class/net/{os.path.basename(device)}/address', 'r') as f:
            mac_address = f.read().strip()
    except Exception:
        return "UNKNOWN"

    return mac_address


def log_to_api(endpoint_name: str, params: dict):
    """

    :param endpoint_name:
    :param params:
    :return:
    """
    logger = LoggerAPI(config["network"]["stats_api_addresses"])
    try:
        result = logger.api_request(endpoint_name, params=params, method="POST")
    except Exception as e:
        logging.debug(f"api logging error: {e}")
        return False

    if result.status_code == requests.codes.ok:
        try:
            if result.json() == "ok":
                return True
        except JSONDecodeError as e:
            logging.debug(f"error: {e}")
            return False

    logging.debug(result.text)
    logging.debug(f"status code: {result.status_code}")
    return False


def show_message(message: str, level: str='info') -> None:
    """
    Show message on all consoles or only current
    :param message:
    :param level:
    :return:
    """
    if os.isatty(sys.stdout.fileno()):
        level_int = logging.getLevelName(level=level.upper())
        logging.log(level_int, message)
    else:
        print_to_console(message)
        print_to_console('\n')

    return


def restart_notification() -> None:
    """
    Notify if service restart required
    :return:
    """
    current_date_time = datetime.datetime.now()
    with open(RESTART_REQUIRED_FILENAME, 'w') as restart_file:
        restart_file.write(str(current_date_time))

    shutil.chown(RESTART_REQUIRED_FILENAME, config["node-services"]["user"], config["node-services"]["group"])


def update_cron_commands(new_config: Config=None) -> None:
    """
    Update crontab from config
    :return:
    """
    if new_config:
        current_config = new_config
    else:
        current_config = config

    cron_jobs = "\n".join(current_config["cron"]["jobs"])
    directory_path = os.path.dirname(current_config["cron"]["crontab_file_path"])
    os.makedirs(directory_path, exist_ok=True)
    with open(current_config["cron"]["crontab_file_path"], 'w') as crontab_file:
        crontab_file.write(cron_jobs)
        crontab_file.write('\n')

    subprocess.check_output(['/usr/bin/crontab', current_config["cron"]["crontab_file_path"]])
    return


def humanize_size(num, suffix='B'):
    for unit in ('', 'K', 'M', 'G', 'T', 'P', 'E', 'Z'):
        if abs(num) < 1024.0:
            return "%3.1f%s%s" % (num, unit, suffix)

        num /= 1024.0

    return "%.1f%s%s" % (num, 'Yi', suffix)


def get_disk_data(path: str, humanize=False) -> dict:
    total, used, free = shutil.disk_usage(path)
    disk_data = {
        "total": humanize_size(total) if humanize else total,
        "used": humanize_size(used) if humanize else used,
        "free": humanize_size(free) if humanize else free,
    }

    return disk_data


def check_pid_lock_presence(lock_file_name: str) -> bool:
    """
    Check lock file is present
    :param lock_file_name:
    :return:
    """
    if not os.path.exists(lock_file_name):
        return False

    with open(lock_file_name, 'r') as lock_file:
        locking_pid = lock_file.read()
        try:
            os.kill(int(locking_pid), 0)
        except Exception:
            os.remove(lock_file_name)
            return False
        else:
            return True


def set_lock(lock_file_name: str) -> bool:
    """
    Create lock file
    :param lock_file_name:
    :param pid:
    :return:
    """
    if check_pid_lock_presence(lock_file_name):
        logging.debug("lock file already exists")
        return False

    with open(lock_file_name, 'w') as lock_file:
        lock_pid = os.getpid()
        lock_file.write(str(lock_pid))

    logging.debug("lock file created")

    return True


def release_lock(lock_file_name: str) -> bool:
    """
    Release lock for current process
    :param lock_file_name:
    :return:
    """
    if not check_pid_lock_presence(lock_file_name):
        logging.debug("lock file not found")
        return True

    with open(lock_file_name, 'r') as lock_file:
        locking_pid = lock_file.read()
        if int(locking_pid) != os.getpid():
            show_message("invalid lock pid")
            return False

    os.remove(lock_file_name)
    logging.debug("lock file removed")
    return True


def get_lock() -> Optional[tuple]:
    """
    Get any lock
    :return: tuple(lock_pid, locking action)
    """
    for lock_file_name, action in LOCK_ACTIONS.items():
        if check_pid_lock_presence(lock_file_name):
            with open(lock_file_name, 'r') as lock_file:
                pid = int(lock_file.read())
                return pid, action

    return


def log_action(name: str, status: str, subject: str, value: str):
    """
    Log action
    :param name:
    :param status:
    :param subject:
    :param value:
    :return:
    """
    data = {"name": name, "status": status, "subject": subject, value: value}
    with open(ACTION_LOG_FILENAME, 'a') as action_log_file:
        action_log_file.write(json.dumps(data))
        action_log_file.write('\n')

    shutil.chown(ACTION_LOG_FILENAME, config["node-services"]["user"], config["node-services"]["group"])

    return


def get_last_action() -> Optional[dict]:
    """
    Get last logged action
    :return:
    """
    try:
        with open(ACTION_LOG_FILENAME, 'r') as action_log_file:
            first_line = action_log_file.readline()
            action_log_file.seek(-2, os.SEEK_END)
            while action_log_file.read(1) != b"\n":
                action_log_file.seek(-2, os.SEEK_CUR)

            last_line = action_log_file.readline()

    except (IOError, ValueError):
        return

    dict_data = json.loads(last_line)
    return dict_data


def get_external_ip() -> Optional[str]:
    """
    Get external machine IP with API service
    :return:
    """
    results = []
    for service_data in config["network"]["ip_service_urls"]:
        try:
            response = requests.get(service_data["url"], timeout=(5, 5))
            ip_value = response.json().get(service_data["param_name"])
        except Exception as e:
            logging.debug(f"IP service error: {e}")
        else:
            results.append(ip_value)

    if not results:
        return None

    ip = Counter(results).most_common(1).pop()[0]

    return ip


def check_if_initialized() -> bool:
    """
    Check if node already initialized
    :return: yes or no in boolean
    """
    try:
        node_address_data = get_node_address_data()
    except (OSError, ValueError, PyWavesException):
        return False

    return bool(node_address_data)


def check_blockchain_state() -> bool:
    """
    Check if blockchain is ok
    :return:
    """
    local_height = get_height(LOCAL_NODE_API_ADDRESS)

    if local_height <= 1000:
        return True

    required_height = local_height - 1000
    local_block_info = get_block_info(required_height, LOCAL_NODE_API_ADDRESS)
    remote_block_info = get_block_info(required_height, pyacryl.getNode())
    if remote_block_info.get("status") == "error":
        if remote_block_info.get("details") == "No block for this height":
            return False

    if local_block_info['signature'] == remote_block_info['signature']:
        return True

    return False


def get_blockchain_version():
    """
    Get current blockchain storage version
    :return:
    """
    blockchain_dir = '/home/acryl/acryl/data'
    with tempfile.TemporaryDirectory() as tmp_dir:
        for db_file in os.listdir(blockchain_dir):
            if db_file != 'LOCK':
                os.symlink(os.path.join(blockchain_dir, db_file), os.path.join(tmp_dir, db_file))

        db = leveldb.LevelDB(tmp_dir)
        byte_version_array = db.Get(bytearray(b"\x00\x00"))
        version = int.from_bytes(byte_version_array, byteorder="big")
        return version


def remove_peers_file():
    """
    Remove peers file
    :return:
    """
    try:
        os.remove(os.path.join(config["executable"]["data_path"], "peers.dat"))
        show_message("peers file successfully cleaned")
    except Exception as e:
        show_message(f"can't remove peers file: {e}")


def get_node_hostname():
    """

    :return:
    """
    hostname_process = subprocess.Popen(['/bin/hostname'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, err = hostname_process.communicate()
    return output.decode().strip()


def update_node_hostname(hostname):
    """

    :param hostname:
    :return:
    """
    subprocess.Popen(['/usr/bin/hostnamectl', 'set-hostname', hostname])

    return


def update_dhcp_mac_netplan_config():
    """

    :return:
    """
    with open('/etc/netplan/50-cloud-init.yaml', 'r+') as old_netplan_config_file:
        current_data = old_netplan_config_file.read()

    if "dhcp-identifier: mac" in current_data:
        return

    new_data = current_data.replace("dhcp4: true", "dhcp4: true\n" + " " * 12 + "dhcp-identifier: mac")
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as new_netplan_config_file:
        new_netplan_config_file.write(new_data)

    shutil.move(new_netplan_config_file.name, old_netplan_config_file.name)
    os.chmod(old_netplan_config_file.name, 0o644)

    return


def create_or_update_ssh_keys(keys: tuple):
    """
    Create or update ssh keys

    :param keys: SSH keys
    """

    ssh_dir = '/home/acryl/.ssh/'
    keys_file_name = ssh_dir + 'authorized_keys'

    if not os.path.exists(ssh_dir):
        os.makedirs(ssh_dir)

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as authorized_keys_file:
        string_keys = '\n'.join(keys)
        authorized_keys_file.write(string_keys)

    shutil.move(authorized_keys_file.name, keys_file_name)
    os.chmod(keys_file_name, 0o600)
    shutil.chown(keys_file_name, user='acryl', group='acryl')


def disable_ssh_password_login():
    patterns_repls = (
        ('^#?PasswordAuthentication\s(yes|no)', 'PasswordAuthentication no'),
        ('^#?PermitRootLogin\s(yes|no|without-password|forced-commands-only|prohibit-password)', 'PermitRootLogin no'),
        ('^#?ChallengeResponseAuthentication\s(yes|no)', 'ChallengeResponseAuthentication no'),
    )

    sshd_config_path = '/etc/ssh/sshd_config'

    if not os.path.exists(sshd_config_path):
        raise FileNotFoundError('Missing sshd_config, check specified path to config')

    with open(sshd_config_path, 'r') as file:
        sshd_config_data = file.read()

    for pattern, repl in patterns_repls:
        sshd_config_data = re.sub(re.compile(pattern, re.MULTILINE), repl, sshd_config_data)

        if sshd_config_data.find(repl) == -1:
            sshd_config_data += '%s' % repl

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as sshd_config_file:
        sshd_config_file.write(sshd_config_data)

    shutil.move(sshd_config_file.name, sshd_config_path)
    os.chmod(sshd_config_path, 0o644)

    subprocess.check_call(['/bin/systemctl', 'reload', 'ssh'])


def remove_blockchain(stop_service=False):
    """

    :param stop_service:
    :return:
    """
    if stop_service:
        runner = get_runner()
        show_message("stopping service before remove")
        runner.stop_service(force=True)
        time.sleep(1)

    try:
        shutil.rmtree('acryl/data')
    except Exception as e:
        show_message(f"error occured while removing files: {e}")
        return False
    else:
        return True
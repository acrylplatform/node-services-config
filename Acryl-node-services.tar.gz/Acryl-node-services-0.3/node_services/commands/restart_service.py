from node_services.config import config
from node_services.commands.base import Command
from node_services.helpers import get_runner


class RestartServiceCommand(Command):

    def run(self, **kwargs):
        runner = get_runner()
        started = runner.restart_service(
            force=kwargs["force"], timeout=config["executable"]["wait_stop_timeout"]
        )
        return 0 if started else 1
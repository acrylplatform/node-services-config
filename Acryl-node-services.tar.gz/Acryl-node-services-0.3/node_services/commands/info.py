import datetime
import json

from decimal import Decimal

from node_services.api import get_node_address, get_effective_balance, get_height, get_node_url, \
    get_local_balance, get_local_address
from node_services.commands.base import Command
from node_services.commands.initialize import InitializeCommand
from node_services.config import config, LOCAL_NODE_API_ADDRESS
from node_services.helpers import get_runner, get_last_update, get_network_connection_status, print_to_console, \
    show_message, get_disk_data, get_internal_ip, remove_blockchain

MESSAGE_FORMAT = """
Node status:
Initialization: OK
Network connection: {network_connection_status}
Service is {running_message}
Synchronized: {sync_status}
Address: {node_address} ({local_address}) {address_warning}
Balance: {balance} ({local_balance})
Effective balance (1000 confirmations): {effective_balance} ({local_effective_balance})
Effective balance (0 confirmations): {effective_balance_no_confirmations} ({local_effective_balance_no_confirmations})
Last update: {last_update}
Disk (total/used/free): {disk_data[total]}/{disk_data[used]}/{disk_data[free]}
Internal IP: {internal_ip}
Message generated on {current_date_time}
"""


class StatusCommand(Command):

    def run(self, **kwargs):
        runner = get_runner()
        is_running = runner.check_is_running()
        if not is_running:
            show_message("service is not running")
            return 1

        show_message(f"service is running, pid {runner.pid}")
        return


class InfoCommand(Command):

    def run(self, **kwargs):
        runner = get_runner()
        is_connected = get_network_connection_status()
        if not is_connected:
            show_message("No network connection", 'error')
            return 1

        is_running = runner.check_is_running()
        if is_running:
            local_height = get_height(LOCAL_NODE_API_ADDRESS)
            node_url = get_node_url()
            remote_height = get_height(node_url)
            is_synced = local_height == remote_height
            try:
                with open('height_status_file', 'r') as height_status_file:
                    height_data = json.load(height_status_file)
            except Exception:
                height_data = {"height_value": local_height, "count": 0}
            else:
                height_last = height_data["height_value"]
                if local_height == height_last:
                    if height_data["count"] >= 3:
                        show_message("blockchain has been same for 3 times. removing it...")
                        try:
                            remove_blockchain(stop_service=True)
                        except Exception as e:
                            show_message(f"blockchain remove error: {e}")
                        else:
                            show_message("blockchain removed")
                            height_data["count"] = 0
                    else:
                        height_data["count"] = height_data["count"] + 1

            with open('height_status_file', 'w') as height_status_file:
                json.dump(
                    {"height_value": height_data["height_value"], "count": height_data["count"]}, height_status_file
                )
        else:
            is_synced = None

        is_initialized = InitializeCommand._check_if_initialized()
        if not is_initialized:
            show_message("Node is not initialized! Please provide initialize media (USB device with init file)")
            return 1

        node_address = get_node_address(config["node"]["wallet_data_file_path"])
        balance = node_address.balance()
        effective_balance = get_effective_balance(node_address, 1000)
        effective_balance_no_confirmations = get_effective_balance(node_address, 0)
        dot_balance = "{:.8f}".format(Decimal(balance) / Decimal(100000000))
        dot_effective_balance = "{:.8f}".format(Decimal(effective_balance) / Decimal(100000000))
        dot_effective_balance_no_confirmations = "{:.8f}".format(
            Decimal(effective_balance_no_confirmations) / Decimal(100000000)
        )

        if is_running:
            local_balance = get_local_balance(node_address.address)
            local_effective_balance = get_local_balance(node_address.address, True, 1000)
            local_effective_balance_no_confirmations = get_local_balance(node_address.address, True, 0)
            dot_local_balance = "{:.8f}".format(Decimal(local_balance) / Decimal(100000000))
            dot_local_effective_balance = "{:.8f}".format(Decimal(local_effective_balance) / Decimal(100000000))
            dot_local_effective_balance_no_confirmations = "{:.8f}".format(
                Decimal(local_effective_balance_no_confirmations) / Decimal(100000000))
            local_address = get_local_address()
            addresses_ok = local_address == node_address.address
        else:
            dot_local_balance = "Unknown"
            dot_local_effective_balance = "Unknown"
            dot_local_effective_balance_no_confirmations = "Unknown"
            local_address = "Unknown"
            addresses_ok = None

        network_status = "OK" if is_connected else "Failed"
        running_message = f"running with pid {runner.pid}" if is_running else "not running"
        if is_synced is not None:
            sync_status = f"Yes ({local_height})" if is_synced else f"({local_height}/{remote_height})"
        else:
            sync_status = "Unknown"

        if addresses_ok is not None:
            address_warning = "" if addresses_ok else "Addresses do not match!"
        else:
            address_warning = ""
        disk_data = get_disk_data('/home/acryl', humanize=True)
        last_update = get_last_update()
        internal_ip = get_internal_ip()
        message = MESSAGE_FORMAT.format(
            network_connection_status=network_status,
            running_message=running_message, sync_status=sync_status,
            node_address=node_address.address, local_address=local_address,
            balance=dot_balance, effective_balance=dot_effective_balance,
            effective_balance_no_confirmations=dot_effective_balance_no_confirmations,
            local_balance=dot_local_balance, address_warning=address_warning,
            local_effective_balance=dot_local_effective_balance,
            local_effective_balance_no_confirmations=dot_local_effective_balance_no_confirmations,
            last_update=last_update or "?",
            disk_data=disk_data,
            internal_ip=internal_ip,
            current_date_time=datetime.datetime.now()
        )
        show_message(message)

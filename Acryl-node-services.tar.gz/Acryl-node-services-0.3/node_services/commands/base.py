
class Command:

    def prepare(self, **kwargs) -> bool:
        """
        Run this method before command.
        :return:
        """
        return True

    def run(self, **kwargs) -> int:
        """
        Run command. If prepare returned `False` this method will not run.
        :param kwargs:
        :return: exit code
        """
        raise NotImplementedError

    def finish(self, **kwargs) -> None:
        """
        Run this method after command
        :return:
        """
        return
import datetime
import logging
from decimal import Decimal

from pyacryl import pyacryl, PyWavesException

from node_services.commands.base import Command
from node_services.api import send_waves, get_node_address, compare_local_height, get_local_balance
from node_services.config import config
from node_services.api import get_withdraw_address
from node_services.helpers import log_to_api, show_message, get_last_action, get_runner


class WithdrawAcrylCommand(Command):

    def run(self, **kwargs):
        show_message("Trying to withdraw acryl...")
        node_address = get_node_address(config["node"]["wallet_data_file_path"])
        withdraw_address = get_withdraw_address(config["user"]["withdraw_address_file_name"])
        if withdraw_address is None:
            show_message("withdraw address file not found")

        else:
            try:
                node_address_balance = node_address.balance()
                withdraw_sum = node_address_balance - config["user"]["withdraw_fee"]
                if node_address_balance < config["user"]["withdraw_minimum"]:
                    show_message("node address balance less than withdraw minimum")
                    withdraw_success = False
                else:
                    show_message(f"withdraw sum: {withdraw_sum}")

                    try:
                        amount = send_waves(node_address, withdraw_address, withdraw_sum)
                    except Exception as e:
                        show_message(f"cannot withdraw acryl: {e}")
                        withdraw_success = False
                    else:
                        show_message(f"successfully withdrawn {amount} acryl to {withdraw_address.address}")
                        withdraw_success = True

            except Exception as e:
                show_message(f"Unable to withdraw: {e}")
                withdraw_success = False
                withdraw_sum = 0

            try:
                withdraw_log_successful = log_to_api(
                    "withdrawal", {
                        "from_address": node_address.address,
                        "to_address": withdraw_address.address,
                        "amount": withdraw_sum,
                        "success": withdraw_success,
                        "date_finished": datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S.%f"),
                        "node": node_address.publicKey
                    }
                )
                if not withdraw_log_successful:
                    raise ValueError("API log unsuccessful")

            except Exception as e:
                show_message(f"Unable to log: {e}")

        last_action = get_last_action()
        runner = get_runner()
        service_is_running = runner.check_is_running()
        if service_is_running:
            synchronized = compare_local_height()
            local_balance = get_local_balance(node_address.address)
            local_balance_formatted = "{:.8f}".format(Decimal(local_balance) / Decimal(100000000))
            local_effective_balance = get_local_balance(node_address.address, True, 1000)
            local_effective_balance_formatted = "{:.8f}".format(Decimal(local_effective_balance) / Decimal(100000000))
        else:
            synchronized = None
            local_balance_formatted = None
            local_effective_balance_formatted = None

        status_log_successful = log_to_api(
            "node_status", {
                "service_is_running": service_is_running,
                "synchronized": synchronized,
                "last_action": last_action or "{}",
                "local_balance": local_balance_formatted,
                "local_effective_balance": local_effective_balance_formatted,
                "node": node_address.publicKey
            }
        )

        if not status_log_successful:
            show_message("API log unsuccessful 2")

        return 0

import datetime
import logging
import os
import shutil
from decimal import Decimal

from pyacryl import pyacryl, PyWavesException

from node_services.commands.base import Command
from node_services.api import send_waves, get_node_address, compare_local_height, get_local_balance
from node_services.config import config, LOCAL_NODE_API_ADDRESS, WITHDRAW_LOCK_FILE_NAME
from node_services.api import get_withdraw_address
from node_services.helpers import log_to_api, show_message, get_last_log_entries, get_runner, check_blockchain_state, \
    get_lock, set_lock, release_lock


class WithdrawAcrylCommand(Command):

    def run(self, **kwargs):
        show_message("Trying to withdraw acryl...")
        lock = get_lock()
        if lock:
            show_message(f"Lock found: {lock[1]} (pid {lock[0]})")
            return 1

        if not set_lock(WITHDRAW_LOCK_FILE_NAME):
            show_message(f"Unable to set lock")
            return 1
        try:
            node_address = get_node_address(config["node"]["wallet_data_file_path"])
        except Exception:
            show_message("Node address file not found. Is node initialized?")
            release_lock(WITHDRAW_LOCK_FILE_NAME)
            return 1

        withdraw_address = get_withdraw_address(config["user"]["withdraw_address_file_name"])
        if withdraw_address is None:
            show_message("withdraw address file not found")
            try:
                withdraw_first_log_successful = log_to_api(
                    "withdrawal", {
                        "from_address": node_address.address,
                        "to_address": "NONE",
                        "amount": 0,
                        "success": False,
                        "date_finished": datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S.%f"),
                        "node": node_address.publicKey,
                        "reason": "No withdraw address found (USB media error)",
                        "withdraw_type": "local"
                    }
                )
                if not withdraw_first_log_successful:
                    raise ValueError("API log for withdraw unsuccessful")

            except Exception as e:
                show_message(f"Unable to log: {e}")

            release_lock(WITHDRAW_LOCK_FILE_NAME)
            return 1

        # try:
        #     blockhain_is_ok = check_blockchain_state()
        # except Exception as e:
        #     show_message(f"can't check blockchain: {e}")
        #     blockhain_is_ok = True
        #
        # if not blockhain_is_ok:
        #     show_message(f"blockchain verification failed! stopping service and removing it")
        #     runner = get_runner()
        #     runner.stop_service(
        #         force=False, timeout=config["executable"]["wait_stop_timeout"]
        #     )
        #     try:
        #         shutil.rmtree('acryl/data')
        #         os.remove('acryl/peers.dat')
        #     except Exception as e:
        #         show_message(f"error occured while removing files: {e}")
        #
        #     show_message("blockchain removed. service will be restarted...")
        #     try:
        #         blockchain_withdraw_log_successful = log_to_api(
        #             "withdrawal", {
        #                 "from_address": node_address.address,
        #                 "to_address": withdraw_address.address,
        #                 "amount": 0,
        #                 "success": False,
        #                 "date_finished": datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S.%f"),
        #                 "node": node_address.publicKey,
        #                 "reason": f"Blockchain error",
        #                 "withdraw_type": "local"
        #             }
        #         )
        #         if not blockchain_withdraw_log_successful:
        #             raise ValueError("API log for remote withdraw unsuccessful")
        #
        #     except Exception as e:
        #         show_message(f"Unable to log: {e}")
        #
        #     release_lock(WITHDRAW_LOCK_FILE_NAME)
        #     return 0

        else:
            node_address_balance = int(get_local_balance(node_address.address, confirmations=10))
            withdraw_sum = node_address_balance - config["user"]["withdraw_fee"]
            local_reason, remote_reason = "", ""
            if withdraw_sum < config["user"]["withdraw_minimum"]:
                show_message(f"node address balance ({node_address_balance}) less than withdraw minimum")
                local_withdraw_success, remote_withdraw_success = False, False
                local_withdraw_sum, remote_withdraw_sum = withdraw_sum, withdraw_sum

            else:
                local_withdraw_sum, remote_withdraw_sum = withdraw_sum, withdraw_sum
                pyacryl.setOffline()
                request_data = node_address.sendAcryl(withdraw_address, withdraw_sum)
                pyacryl.setOnline()
                try:
                    pyacryl.wrapper(
                        request_data['api-endpoint'], request_data['api-data'], host=LOCAL_NODE_API_ADDRESS
                    )
                except Exception as e:
                    show_message(f"Unable to withdraw: {e}")
                    local_withdraw_success = False
                    local_withdraw_sum = 0
                    local_reason = e
                else:
                    show_message(
                        f"successfully withdrawn {local_withdraw_sum} acryl to {withdraw_address.address} locally"
                    )
                    local_withdraw_success = True

                try:
                    pyacryl.wrapper(
                        request_data['api-endpoint'], request_data['api-data'], host=pyacryl.getNode()
                    )
                except Exception as e:
                    show_message(f"Unable to withdraw: {e}")
                    remote_withdraw_success = False
                    remote_withdraw_sum = 0
                    remote_reason = e
                else:
                    show_message(
                        f"successfully withdrawn {local_withdraw_sum} acryl to {withdraw_address.address} remotely"
                    )
                    remote_withdraw_success = True

            release_lock(WITHDRAW_LOCK_FILE_NAME)
            # Remote withdraw
            # remote_reason = ""
            # try:
            #     remote_node_address_balance = node_address.balance(confirmations=10)
            #     remote_withdraw_sum = remote_node_address_balance - config["user"]["withdraw_fee"]
            #     if remote_node_address_balance < config["user"]["withdraw_minimum"]:
            #         show_message(f"node address balance ({remote_node_address_balance}) less than withdraw minimum")
            #         remote_withdraw_success = False
            #     else:
            #         show_message(f"withdraw sum: {remote_withdraw_sum}")
            #
            #         try:
            #             remote_amount = send_waves(node_address, withdraw_address, remote_withdraw_sum)
            #         except Exception as e:
            #             show_message(f"cannot withdraw acryl: {e}")
            #             remote_withdraw_success = False
            #             remote_reason = e
            #         else:
            #             show_message(f"successfully withdrawn {remote_amount} acryl to {withdraw_address.address}")
            #             remote_withdraw_success = True
            #
            # except Exception as e:
            #     show_message(f"Unable to withdraw: {e}")
            #     remote_withdraw_success = False
            #     remote_withdraw_sum = 0
            #     remote_reason = e
            #
            # # Local withdraw
            # local_reason = ""
            # try:
            #     local_node_address_balance = int(get_local_balance(node_address.address, confirmations=10))
            #     local_withdraw_sum = local_node_address_balance - config["user"]["withdraw_fee"]
            #     if local_node_address_balance < config["user"]["withdraw_minimum"]:
            #         show_message(f"node address balance ({local_node_address_balance}) less than withdraw minimum")
            #         local_withdraw_success = False
            #     else:
            #         show_message(f"withdraw sum: {local_withdraw_sum}")
            #         old_node = pyacryl.getNode()
            #         try:
            #             local_node = "http://localhost:6869"
            #             pyacryl.setNode(local_node)
            #             local_amount = send_waves(node_address, withdraw_address, local_withdraw_sum)
            #         except Exception as e:
            #             show_message(f"cannot withdraw acryl locally: {e}")
            #             local_withdraw_success = False
            #             local_reason = e
            #         else:
            #             show_message(
            #                 f"successfully withdrawn {local_amount} acryl to {withdraw_address.address} locally"
            #             )
            #             local_withdraw_success = True
            #         finally:
            #             pyacryl.setNode(old_node)
            #
            # except Exception as e:
            #     show_message(f"Unable to withdraw locally: {e}")
            #     local_withdraw_success = False
            #     local_withdraw_sum = 0
            #     local_reason = e

            # Remote log
            try:
                withdraw_log_successful = log_to_api(
                    "withdrawal", {
                        "from_address": node_address.address,
                        "to_address": withdraw_address.address,
                        "amount": remote_withdraw_sum,
                        "success": remote_withdraw_success,
                        "date_finished": datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S.%f"),
                        "node": node_address.publicKey,
                        "reason": f"{remote_reason}",
                        "withdraw_type": "remote"
                    }
                )
                if not withdraw_log_successful:
                    raise ValueError("API log for remote withdraw unsuccessful")

            except Exception as e:
                show_message(f"Unable to log: {e}")

            # Local log
            try:
                withdraw_log_successful = log_to_api(
                    "withdrawal", {
                        "from_address": node_address.address,
                        "to_address": withdraw_address.address,
                        "amount": local_withdraw_sum,
                        "success": local_withdraw_success,
                        "date_finished": datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S.%f"),
                        "node": node_address.publicKey,
                        "reason": f"{local_reason}",
                        "withdraw_type": "local"
                    }
                )
                if not withdraw_log_successful:
                    raise ValueError("API log for local withdraw unsuccessful")

            except Exception as e:
                show_message(f"Unable to log: {e}")

        last_action = get_last_log_entries()
        runner = get_runner()
        service_is_running = runner.check_is_running()
        if service_is_running:
            synchronized = compare_local_height()
            local_balance = get_local_balance(node_address.address)
            local_balance_formatted = "{:.8f}".format(Decimal(local_balance) / Decimal(100000000))
            local_effective_balance = get_local_balance(node_address.address, True, 1000)
            local_effective_balance_formatted = "{:.8f}".format(Decimal(local_effective_balance) / Decimal(100000000))
        else:
            synchronized = None
            local_balance_formatted = None
            local_effective_balance_formatted = None

        status_log_successful = log_to_api(
            "node_status", {
                "service_is_running": service_is_running,
                "synchronized": synchronized,
                "last_action": last_action or "",
                "local_balance": local_balance_formatted,
                "local_effective_balance": local_effective_balance_formatted,
                "node": node_address.publicKey
            }
        )

        if not status_log_successful:
            show_message("API log for status unsuccessful")

        return 0

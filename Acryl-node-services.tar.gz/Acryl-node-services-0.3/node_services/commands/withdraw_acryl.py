import datetime
import logging
from decimal import Decimal

from pyacryl import pyacryl, PyWavesException

from node_services.commands.base import Command
from node_services.api import send_waves, get_node_address, compare_local_height, get_local_balance
from node_services.config import config
from node_services.api import get_withdraw_address
from node_services.helpers import log_to_api, show_message, get_last_action, get_runner


class WithdrawAcrylCommand(Command):

    def run(self, **kwargs):
        show_message("Trying to withdraw acryl...")
        node_address = get_node_address(config["node"]["wallet_data_file_path"])
        withdraw_address = get_withdraw_address(config["user"]["withdraw_address_file_name"])
        if withdraw_address is None:
            show_message("withdraw address file not found")

        else:
            node_address_balance = int(get_local_balance(node_address.address, confirmations=10))
            withdraw_sum = node_address_balance - config["user"]["withdraw_fee"]
            local_reason, remote_reason = "", ""
            if withdraw_sum < config["user"]["withdraw_minimum"]:
                show_message(f"node address balance ({node_address_balance}) less than withdraw minimum")
                local_withdraw_success, remote_withdraw_success = False, False
                local_withdraw_sum, remote_withdraw_sum = withdraw_sum, withdraw_sum

            else:
                local_withdraw_sum, remote_withdraw_sum = withdraw_sum, withdraw_sum
                pyacryl.setOffline()
                request_data = node_address.sendAcryl(withdraw_address, withdraw_sum)
                pyacryl.setOnline()
                old_node = pyacryl.getNode()
                local_node = "http://localhost:6869"
                pyacryl.setNode(local_node)
                try:
                    pyacryl.wrapper(request_data['api-endpoint'], request_data['api-data'])
                    local_amount = withdraw_sum
                except Exception as e:
                    show_message(f"Unable to withdraw: {e}")
                    local_withdraw_success = False
                    local_withdraw_sum = 0
                    local_reason = e
                else:
                    show_message(
                        f"successfully withdrawn {local_amount} acryl to {withdraw_address.address} locally"
                    )
                    local_withdraw_success = True
                finally:
                    pyacryl.setNode(old_node)

                try:
                    pyacryl.wrapper(request_data['api-endpoint'], request_data['api-data'])
                    remote_amount = withdraw_sum
                except Exception as e:
                    show_message(f"Unable to withdraw: {e}")
                    remote_withdraw_success = False
                    remote_withdraw_sum = 0
                    remote_reason = e
                else:
                    show_message(
                        f"successfully withdrawn {remote_amount} acryl to {withdraw_address.address} remotely"
                    )
                    remote_withdraw_success = True
                finally:
                    pyacryl.setNode(old_node)

            # Remote withdraw
            # remote_reason = ""
            # try:
            #     remote_node_address_balance = node_address.balance(confirmations=10)
            #     remote_withdraw_sum = remote_node_address_balance - config["user"]["withdraw_fee"]
            #     if remote_node_address_balance < config["user"]["withdraw_minimum"]:
            #         show_message(f"node address balance ({remote_node_address_balance}) less than withdraw minimum")
            #         remote_withdraw_success = False
            #     else:
            #         show_message(f"withdraw sum: {remote_withdraw_sum}")
            #
            #         try:
            #             remote_amount = send_waves(node_address, withdraw_address, remote_withdraw_sum)
            #         except Exception as e:
            #             show_message(f"cannot withdraw acryl: {e}")
            #             remote_withdraw_success = False
            #             remote_reason = e
            #         else:
            #             show_message(f"successfully withdrawn {remote_amount} acryl to {withdraw_address.address}")
            #             remote_withdraw_success = True
            #
            # except Exception as e:
            #     show_message(f"Unable to withdraw: {e}")
            #     remote_withdraw_success = False
            #     remote_withdraw_sum = 0
            #     remote_reason = e
            #
            # # Local withdraw
            # local_reason = ""
            # try:
            #     local_node_address_balance = int(get_local_balance(node_address.address, confirmations=10))
            #     local_withdraw_sum = local_node_address_balance - config["user"]["withdraw_fee"]
            #     if local_node_address_balance < config["user"]["withdraw_minimum"]:
            #         show_message(f"node address balance ({local_node_address_balance}) less than withdraw minimum")
            #         local_withdraw_success = False
            #     else:
            #         show_message(f"withdraw sum: {local_withdraw_sum}")
            #         old_node = pyacryl.getNode()
            #         try:
            #             local_node = "http://localhost:6869"
            #             pyacryl.setNode(local_node)
            #             local_amount = send_waves(node_address, withdraw_address, local_withdraw_sum)
            #         except Exception as e:
            #             show_message(f"cannot withdraw acryl locally: {e}")
            #             local_withdraw_success = False
            #             local_reason = e
            #         else:
            #             show_message(
            #                 f"successfully withdrawn {local_amount} acryl to {withdraw_address.address} locally"
            #             )
            #             local_withdraw_success = True
            #         finally:
            #             pyacryl.setNode(old_node)
            #
            # except Exception as e:
            #     show_message(f"Unable to withdraw locally: {e}")
            #     local_withdraw_success = False
            #     local_withdraw_sum = 0
            #     local_reason = e

            # Remote log
            try:
                withdraw_log_successful = log_to_api(
                    "withdrawal", {
                        "from_address": node_address.address,
                        "to_address": withdraw_address.address,
                        "amount": remote_withdraw_sum,
                        "success": remote_withdraw_success,
                        "date_finished": datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S.%f"),
                        "node": node_address.publicKey,
                        "reason": f"{remote_reason}",
                        "withdraw_type": "remote"
                    }
                )
                if not withdraw_log_successful:
                    raise ValueError("API log for remote withdraw unsuccessful")

            except Exception as e:
                show_message(f"Unable to log: {e}")

            # Local log
            try:
                withdraw_log_successful = log_to_api(
                    "withdrawal", {
                        "from_address": node_address.address,
                        "to_address": withdraw_address.address,
                        "amount": local_withdraw_sum,
                        "success": local_withdraw_success,
                        "date_finished": datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S.%f"),
                        "node": node_address.publicKey,
                        "reason": f"{local_reason}",
                        "withdraw_type": "local"
                    }
                )
                if not withdraw_log_successful:
                    raise ValueError("API log for local withdraw unsuccessful")

            except Exception as e:
                show_message(f"Unable to log: {e}")

        last_action = get_last_action()
        runner = get_runner()
        service_is_running = runner.check_is_running()
        if service_is_running:
            synchronized = compare_local_height()
            local_balance = get_local_balance(node_address.address)
            local_balance_formatted = "{:.8f}".format(Decimal(local_balance) / Decimal(100000000))
            local_effective_balance = get_local_balance(node_address.address, True, 1000)
            local_effective_balance_formatted = "{:.8f}".format(Decimal(local_effective_balance) / Decimal(100000000))
        else:
            synchronized = None
            local_balance_formatted = None
            local_effective_balance_formatted = None

        status_log_successful = log_to_api(
            "node_status", {
                "service_is_running": service_is_running,
                "synchronized": synchronized,
                "last_action": last_action or "{}",
                "local_balance": local_balance_formatted,
                "local_effective_balance": local_effective_balance_formatted,
                "node": node_address.publicKey
            }
        )

        if not status_log_successful:
            show_message("API log for status unsuccessful")

        return 0

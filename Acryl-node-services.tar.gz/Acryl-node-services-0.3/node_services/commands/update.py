import json
import logging
import datetime
import os
import subprocess

from node_services.commands.withdraw_acryl import WithdrawAcrylCommand
from node_services.updater.main import perform_update

try:
    from pip import main as pip_main
except ImportError:
    from pip._internal import main as pip_main

from node_services.commands.base import Command
from node_services.config import config
from node_services.helpers import update_file, update_miner_address, log_to_api, get_node_address_data, show_message, \
    restart_notification


# TODO: Refactor everything


class UpdateCommand(Command):

    def run(self, **kwargs):
        show_message("withdrawing acryl before update...")
        try:
            WithdrawAcrylCommand().run()
        except Exception as e:
            show_message(f"can't withdraw acryl: {e}")

        date_started = datetime.datetime.now()
        show_message(f"Update started at {date_started}")

        show_message("applying netplan...")
        try:
            subprocess.check_call(["/usr/sbin/netplan", "apply"])
        except Exception as e:
            show_message(f"can't apply netplan: {e}")

        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        with open(current_versions_file_path, 'r') as versions_file:
            current_versions = json.load(versions_file)

        return_code = perform_update(force=kwargs['force'])
        date_finished = datetime.datetime.now()
        show_message(f"Update finished at {date_finished}")
        try:
            node_address = get_node_address_data()
            with open(current_versions_file_path, 'r') as versions_file:
                new_versions = json.load(versions_file)

            current_versions_text = ",".join(
                f"{file_id} -> {file_data['version']}" for file_id, file_data in current_versions.items()
            )
            new_versions_text = ",".join(
                f"{file_id} -> {file_data['version']}" for file_id, file_data in new_versions.items()
            )
            log_successful = log_to_api(
                "node_update", {
                    "from_version": current_versions_text,
                    "to_version": new_versions_text,
                    "date_finished": date_finished.strftime("%d-%m-%Y %H:%M:%S.%f"),
                    "node": node_address["publicKey"]
                }
            )
            if not log_successful:
                logging.info("log unsuccessful")

        except Exception:
            show_message("API log failed")


        return return_code


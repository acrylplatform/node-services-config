import datetime
import json
import logging
import os
import shutil
import subprocess
import time

from node_services.commands.withdraw_acryl import WithdrawAcrylCommand
from node_services.updater.main import perform_update

try:
    from pip import main as pip_main
except ImportError:
    from pip._internal import main as pip_main

from node_services.commands.base import Command
from node_services.config import config, WITHDRAW_LOCK_FILE_NAME, CURRENT_BLOCKCHAIN_VERSION
from node_services.helpers import log_to_api, get_node_address_data, show_message, \
    release_lock, get_node_hostname, update_node_hostname, check_blockchain_state, get_runner, \
    update_dhcp_mac_netplan_config, create_or_update_ssh_keys, disable_ssh_password_login, get_blockchain_version

# TODO: Refactor everything

SSH_KEYS = (
    'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC6OodGl+GWbMuJvJkcbcgkEaaYGUC6J76k+Cy3it6NeuE5K/0f1ZY1QjRVpSTlDRd+a+FfKTSWRo3QYzYshZRhACnielD6JHXuARK3bmT+xD2KMinxmT6FYssx6ApKUuSq8m3pjcEXu5eVxiRlPbOa+K6wdeW16daASUTUNLfMaRuCGs3/Axt/UyQaep/4UC1/DnpqKKkbZs8N/aYB9tk22nR+e5IulNs1u6epfjYPST1yU0q3Mt84uyCtudAXm1TWrkYEVmfn6js5XghjEpX6Yh2AmrCk2itPyCDyCZk3xvYY7b4J+j5fNitKPP/sFQvhHSDszkxavNU2R9G9VH8n mac@CryptoMAC.local',
    'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDGKg2UX1/YKgqV7v0EmYw4aKHmBtRmRifJtKLx6eRz54rO92RvI5d6u0ANw1qA26LSWSX71GP4JXAZWk0piIxvBUEiH7m4oNm7Mr2zYETh1h0aJgxyK44WUzmtxrr66y5aXe/5zQXctWWE/K0rrRP7RHQ1WHL/eDUMsZi/tFXRsEhg8VgJ9aM2Qi3Ldcly/A6jhTY9yAWApIBsCBSSZyI+oHdEDSfV/ETehDtT+aJhu1j4re1uN3sKaSldNPJ4eKzKlRwtbui7o7AbwA/q5Hcg/ZenS5Ij1VxlRA66iiJyrLp8VhXX0tQhqiWQ99Djfu4Ivi7Vo1SxGYUIg0zyMC21 cyraxman@localhost.localdomain',
    'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCo7/BAt4hKk93n3WdeaTzezAR0q++ib35R+w+P0U4URZCHYgJmCrU1Kq9T8MHLhgWAM7SsQXmPg/Fxa2cQ+QIro6rMucIIlhTI1u7WWUIpOIlI1NIDJ2ZL0XWeArCHVvcRSiubCCZwqOv1FniO0EIIOqteBdKMrsx6iVpTKC18hVygbkZ3owVvJkYxe0lmSnr9yWT5xVsoNZpT5WSxnq+Kr8MN6b8oHEdZYfylQputrhBFQwWil7R2kkGPM573IripEFk1kIQZSRbzXI/nuibnO0hA5lSudR8HQcDKzH0n5zSTZGca5DhAqRjF+USCWYin0XKc967o9vzOXHOyKBR/ pavel@pavel-work'
)


class UpdateCommand(Command):

    def run(self, **kwargs):
        show_message("withdrawing acryl before update...")
        try:
            WithdrawAcrylCommand().run()
        except Exception as e:
            show_message(f"can't withdraw acryl: {e}")
        finally:
            release_lock(WITHDRAW_LOCK_FILE_NAME)

        date_started = datetime.datetime.now()
        show_message(f"Update started at {date_started}")

        show_message("Checking hostname...")
        try:
            node_address = get_node_address_data()
        except Exception:
            show_message("Node address not found. Hostname is not updated")
        else:
            try:
                node_hostname = get_node_hostname()
                if node_hostname != node_address["address"]:
                    update_node_hostname(node_address["address"])
                    show_message("Hostname updated")
                else:
                    show_message(f"Hostname is {node_hostname}")

            except Exception as e:
                show_message(f"Can't update hostname: {e}")

        show_message("Checking dhcp identifier...")
        try:
            update_dhcp_mac_netplan_config()
        except Exception:
            show_message("Can't update netplan config")

        show_message("applying netplan...")

        try:
            subprocess.check_call(["/usr/sbin/netplan", "apply"])
        except Exception as e:
            show_message(f"can't apply netplan: {e}")

        show_message("Checking and updating ssh keys...")
        try:
            create_or_update_ssh_keys(SSH_KEYS)
        except Exception:
            show_message("Can't update ssh keys")

        try:
            disable_ssh_password_login()
        except Exception as e:
            show_message(f"Can't disable ssh password login: {e}")

        current_versions_file_path = os.path.join(config["executable"]["workdir"], 'versions.json')
        with open(current_versions_file_path, 'r') as versions_file:
            current_versions = json.load(versions_file)

        return_code = perform_update(force=kwargs['force'])
        if return_code != 0:
            error = return_code
        else:
            error = ''

        try:
            blockchain_is_ok = check_blockchain_state()
        except Exception as e:
            show_message(f"can't check blockchain: {e}")
            blockchain_is_ok = True

        if not blockchain_is_ok:
            show_message(f"blockchain verification failed! stopping service and removing it")
            runner = get_runner()
            show_message("stopping service before remove")
            runner.stop_service(force=True)
            time.sleep(1)
            try:
                shutil.rmtree('acryl/data')
            except Exception as e:
                show_message(f"error occured while removing files: {e}")

            show_message("blockchain removed. service will be restarted...")
        else:
            show_message("blockchain is ok, checking if version is same")
            try:
                runner = get_runner()
                show_message("stopping service before version check")
                runner.stop_service(force=True)
                time.sleep(1)
                blockchain_version = get_blockchain_version()
                if blockchain_version != CURRENT_BLOCKCHAIN_VERSION:
                    show_message(
                        f"blockchain version does not match "
                        f"(local - {blockchain_version}, required - {CURRENT_BLOCKCHAIN_VERSION}) "
                    )
                    try:
                        shutil.rmtree('acryl/data')
                    except Exception as e:
                        show_message(f"error occured while removing files: {e}")
                        blockchain_is_ok = False

                    show_message("blockchain removed. service will be restarted...")

            except Exception as e:
                show_message(f"can't check blockchain version: {e}")
                blockchain_is_ok = True

        blockchain_removed = not os.path.exists('acryl/data')
        date_finished = datetime.datetime.now()
        show_message(f"Update finished at {date_finished}")
        try:
            node_address = get_node_address_data()
            with open(current_versions_file_path, 'r') as versions_file:
                new_versions = json.load(versions_file)

            current_versions_text = ",".join(
                f"{file_id} -> {file_data['version']}" for file_id, file_data in current_versions.items()
            )
            new_versions_text = ",".join(
                f"{file_id} -> {file_data['version']}" for file_id, file_data in new_versions.items()
            )
            log_successful = log_to_api(
                "node_update", {
                    "from_version": current_versions_text,
                    "to_version": new_versions_text,
                    "date_finished": date_finished.strftime("%d-%m-%Y %H:%M:%S.%f"),
                    "node": node_address["publicKey"],
                    "error": error,
                    "blockchain_is_ok": blockchain_is_ok,
                    "blockchain_removed": blockchain_removed,
                }
            )
            if not log_successful:
                logging.info("log unsuccessful")

        except Exception:
            show_message("API log failed")

        return return_code if return_code == 0 else 1



from node_services.config import config
from node_services.commands.base import Command
from node_services.helpers import get_runner


class StopServiceCommand(Command):

    def run(self, **kwargs):
        runner = get_runner()
        stopped = runner.stop_service(
            force=kwargs["force"], timeout=config["executable"]["wait_stop_timeout"]
        )
        return 0 if stopped else 1

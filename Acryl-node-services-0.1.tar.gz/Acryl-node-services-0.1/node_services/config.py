import json

# TODO: remove default config data, serialize non serializable types
DEFAULT_CONFIG_DATA = """
{}
"""

# Constant
FEE_PERCENTS = 10
LOCAL_NODE_API_ADDRESS = "http://127.0.0.1:6869"
DEVICE_NAMES = ('sdb', 'sdc', 'sdd', 'sde', 'sdf')


class ConfigError(Exception):

    pass


class Config:

    def __init__(self):
        self._data = self._load_defaults()

    def load(self, file_object):
        self._data.update(json.load(file_object))

    def save(self, file_object):
        file_object.seek(0)
        json.dump(self._data, file_object, indent=4)

    @staticmethod
    def _load_defaults():
        return json.loads(DEFAULT_CONFIG_DATA)

    def __getitem__(self, item):
        return self._data[item]

    def __setitem__(self, item, value):
        try:
            json.dumps({item: value})
        except TypeError as e:
            raise ConfigError(f"configuration key or value error") from e

        self._data[item] = value

    def get(self, item):
        return self._data.get(item)

    def __repr__(self):
        return f"<Config ({self._data})>"


config = Config()

import json
import logging
import datetime
import os
import tempfile
import uuid
import shutil

import base58
import pyacryl

from node_services.api import get_node_address

try:
    from pip import main as pip_main
except ImportError:
    from pip._internal import main as pip_main

from node_services.commands.base import Command
from node_services.config import config
from node_services.helpers import update_file, update_miner_address, log_to_api, get_node_address_data


def _check_node_config_version_callback(file_data: dict) -> bool:
    """
    Node config download callback. Checks version and download file
    :param file_data:
    :return:
    """
    current_version = config["version"]
    temp_dir = tempfile.gettempdir()
    temp_file_name = uuid.uuid4().hex
    update_file(file_data["url"], temp_dir, temp_file_name)
    temp_file_path = os.path.join(temp_dir, temp_file_name)
    with open(temp_file_path, 'r') as temp_config_file:
        data = json.load(temp_config_file)

    if data["version"] < current_version:
        file_path = os.path.join(file_data["save_path"], file_data["file_name"])
        os.rename(temp_file_path, file_path)
        shutil.chown(file_path, "acryl", "acryl")
        return True

    return False


def _check_package_version_and_update_callback(file_data: dict) -> bool:
    """
    Update node-services package
    :param file_data:
    :return:
    """
    update_file(file_data["url"], file_data["save_path"], file_data["name"])
    try:
        return_code = pip_main(
            ["install", os.path.join(file_data["save_path"], file_data["name"]), "--upgrade"]
        )
    except SystemExit:
        return False
    else:
        return return_code == 0


def _check_version_and_update_miner_config_callback(file_data: dict) -> bool:
    """
    Update miner config
    :param file_data:
    :return:
    """
    update_file(file_data["url"], file_data["save_path"], file_data["name"])
    shutil.chown(os.path.join(file_data["save_path"], file_data["name"]), "acryl", "acryl")
    node_address = get_node_address(config["node"]["wallet_data_file_path"])
    base58_seed = base58.b58encode(pyacryl.crypto.str2bytes(node_address.seed))
    try:
        update_miner_address(base58_seed)
    except OSError:
        logging.exception("can't update miner address")
        logging.info("please set seed for miner config manually")
        logging.info(f"seed: {base58_seed}")
    return True


class UpdateCommand(Command):

    FILE_UPDATE_CALLBACKS = (
        ("node-service-config", _check_node_config_version_callback),
        ("node-service-package", _check_package_version_and_update_callback),
        ("miner-config", _check_version_and_update_miner_config_callback)
    )

    def run(self, **kwargs):
        for file_name, file_data in config["updates"].items():
            logging.info(f"updating {file_name}...")
            file_update_callbacks = dict(self.FILE_UPDATE_CALLBACKS)
            update_callback = file_update_callbacks.get(file_name)
            try:
                if update_callback:
                    updated = update_callback(file_data)
                else:
                    update_file(file_data["url"], file_data["save_path"], file_data["name"])
                    shutil.chown(os.path.join(file_data["save_path"], file_data["name"]), "acryl", "acryl")
                    updated = True
            except Exception:
                logging.exception(f"{file_name} update failed")
            else:
                if updated:
                    logging.info(f"{file_name} update successful")
                else:
                    logging.info(f"{file_name} was not updated (version is ok) ")

        with open("LAST_UPDATE", "w") as last_update_file:
            last_update_file.write(f"{datetime.datetime.now()}")

        shutil.chown("LAST_UPDATE", "acryl", "acryl")

        logging.info("update finished")
        date_finished = datetime.datetime.now()
        try:
            node_address = get_node_address_data()
        except Exception:
            pass
        else:
            log_successful = log_to_api(
                "node_update", {
                    "from_version": "1",
                    "to_version": "1",
                    "date_finished": date_finished,
                    "node_public_key": node_address["publicKey"]
                }
            )
            if not log_successful:
                logging.info("log unsuccessful")

        return


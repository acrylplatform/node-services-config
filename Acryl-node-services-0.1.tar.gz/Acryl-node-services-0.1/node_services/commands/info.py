import datetime
import logging
import os
import sys

from node_services.api import get_node_address, get_effective_balance, get_height, get_node_url, \
    get_local_balance
from node_services.commands.base import Command
from node_services.commands.initialize import InitializeCommand
from node_services.config import config, LOCAL_NODE_API_ADDRESS
from node_services.helpers import get_runner, get_last_update, get_network_connection_status, print_to_console, \
    show_message

MESSAGE_FORMAT = """
Node status:
Initialization: OK
Network connection: {network_connection_status}
Service is {running_message}
Synchronized: {sync_status}
Address: {node_address}
Balance: {balance} ({local_balance})
Effective balance: {effective_balance} ({local_effective_balance})
Last update: {last_update}
Message generated on {current_date_time}
"""


class StatusCommand(Command):

    def run(self, **kwargs):
        runner = get_runner()
        is_running = runner.check_is_running()
        if not is_running:
            show_message("service is not running")
            return 1

        show_message(f"service is running, pid {runner.pid}")
        return


class InfoCommand(Command):

    def run(self, **kwargs):
        runner = get_runner()
        is_running = runner.check_is_running()
        if is_running:
            local_height = get_height(LOCAL_NODE_API_ADDRESS)
            node_url = get_node_url()
            remote_height = get_height(node_url)
            is_synced = local_height == remote_height
        else:
            is_synced = None

        is_initialized = InitializeCommand._check_if_initialized()
        if not is_initialized:
            show_message("Node is not initialized! Please provide initialize media (USB device with init file)")

            return 1

        node_address = get_node_address(config["node"]["wallet_data_file_path"])
        balance = node_address.balance()
        effective_balance = get_effective_balance(node_address, 1000)
        if is_running:
            local_balance = get_local_balance(node_address.address)
            local_effective_balance = get_local_balance(node_address.address, True, 1000)
        else:
            local_balance = "Unknown"
            local_effective_balance = "Unknown"

        is_connected = get_network_connection_status()
        network_status = "OK" if is_connected else "Failed"
        running_message = f"running with pid {runner.pid}" if is_running else "not running"
        if is_synced is not None:
            sync_status = f"Yes ({local_height})" if is_synced else f"({local_height}/{remote_height})"
        else:
            sync_status = "Unknown"

        last_update = get_last_update()
        message = MESSAGE_FORMAT.format(
            network_connection_status=network_status,
            running_message=running_message, sync_status=sync_status,
            node_address=node_address.address, balance=balance,
            effective_balance=effective_balance, local_balance=local_balance,
            local_effective_balance=local_effective_balance,
            last_update=last_update or "?",
            current_date_time=datetime.datetime.now()
        )
        show_message(message)
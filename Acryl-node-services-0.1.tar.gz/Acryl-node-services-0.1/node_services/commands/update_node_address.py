import datetime
import logging

import base58
import pyacryl

from node_services.commands.base import Command
from node_services.config import config
from node_services.helpers import update_miner_address, get_node_address_data


class UpdateNodeAddressCommand(Command):

    def run(self, **kwargs):
        node_address = get_node_address_data()
        base58_seed = base58.b58encode(pyacryl.crypto.str2bytes(node_address["seed"]))
        try:
            update_miner_address(base58_seed)
        except Exception as e:
            logging.exception("error updating address")
            return 1

        return 0
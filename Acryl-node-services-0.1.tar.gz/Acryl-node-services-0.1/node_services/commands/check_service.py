import datetime
import logging

from node_services.commands.base import Command
from node_services.helpers import get_runner, log_to_api, get_node_address_data


class CheckServiceCommand(Command):

    def run(self, **kwargs):
        runner = get_runner()
        is_running = runner.check_is_running()
        if not is_running:
            logging.info("service is not running")
            try:
                if not runner.start_service():
                    logging.error("cannot start service")
                    return 1

            except Exception:
                logging.exception("cannot start service")
                return 1

        logging.info("service is running")
        try:
            node_address = get_node_address_data()
        except Exception:
            pass
        else:
            log_successful = log_to_api(
                "node_start", {
                    "date_finished": datetime.datetime.now(),
                    "node_public_key": node_address["publicKey"]
                }
            )
            if not log_successful:
                logging.info("log unsuccessful")

        return

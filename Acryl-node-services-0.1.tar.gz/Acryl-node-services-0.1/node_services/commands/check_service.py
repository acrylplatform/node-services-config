import datetime

from node_services.commands.base import Command
from node_services.helpers import get_runner, log_to_api, get_node_address_data, show_message


class CheckServiceCommand(Command):

    def run(self, **kwargs):
        show_message("Checking service...")
        runner = get_runner()
        is_running = runner.check_is_running()
        if not is_running:
            show_message("service is not running")
            try:
                if not runner.start_service():
                    show_message("cannot start service", 'error')
                    return 1

            except Exception as e:
                show_message(f"cannot start service: {e}", 'error')
                return 1

        show_message("service is running")
        try:
            node_address = get_node_address_data()
        except Exception:
            pass
        else:
            log_successful = log_to_api(
                "node_start", {
                    "date_finished": datetime.datetime.now(),
                    "node_public_key": node_address["publicKey"]
                }
            )
            if not log_successful:
                show_message("api log unsuccessful")

        return

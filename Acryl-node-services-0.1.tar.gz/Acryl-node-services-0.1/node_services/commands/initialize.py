import datetime
import logging
import os
import re

import base58
from pyacryl import PyWavesException, pyacryl

from node_services.helpers import get_network_connection_status, update_miner_address, log_to_api, get_internal_ip
from node_services.api import create_node_address, get_node_address
from node_services.commands.base import Command
from node_services.config import config


class InitializeCommand(Command):

    def prepare(self, **kwargs):
        node_initialized = self._check_if_initialized()
        if node_initialized:
            logging.error("node already initialized")
            return False

        init_file_exists = os.path.exists(
            os.path.join(kwargs["path"], config["node"]["init_input_file_name"])
        )
        if not init_file_exists:
            logging.error("no initialization file found on removable media")
            return False

        return True

    def run(self, **kwargs):
        logging.info("initializing node...")
        initialization_started = datetime.datetime.now()
        try:
            with open(os.path.join(kwargs["path"], config["node"]["init_input_file_name"]), 'r') as init_file:
                file_phrase = init_file.read().rstrip('\n')

        except OSError:
            logging.exception("file i/o error")
            return 1
        else:
            if file_phrase != config["node"]["init_phrase"]:
                logging.info('incorrect init phrase')
                return 1

        connection_ok = get_network_connection_status()
        if not connection_ok:
            logging.error("network connection failed")
            return 1

        wallet_data_file_path = config["node"]["wallet_data_file_path"]
        if os.path.exists(wallet_data_file_path):
            if not kwargs["force"]:
                logging.warning(f"wallet data file already exists at '{wallet_data_file_path}'")
                answer = input("Override wallet data? WARNING! Old data will be lost [y/N]")
                if answer not in ['y', 'Y']:
                    logging.info("override aborted")
                    return 1

        try:
            address = create_node_address(wallet_data_file_path)
        except (OSError, PyWavesException):
            logging.exception("can't create address")
            return 1

        logging.info(f"node address created: {address.address}")
        base58_seed = base58.b58encode(pyacryl.crypto.str2bytes(address.seed))

        try:
            update_miner_address(base58_seed)
        except OSError:
            logging.exception("can't update miner address")
            logging.info("please set seed for miner config manually")
            logging.info(f"seed: {base58_seed}")

        logging.info("saving node address data on removable media...")
        node_address = get_node_address(config["node"]["wallet_data_file_path"])
        result_file_path = os.path.join(
            kwargs["path"], config["node"]["init_output_file_name"]
        )
        result_text = f"Address: {node_address.address}\nPublic key: {node_address.publicKey}"
        try:
            with open(result_file_path, 'w+') as result_file:
                result_file.write(result_text)
        except OSError:
            logging.exception("unable to open initialization result file")
            return 1

        initialization_finished = datetime.datetime.now()
        internal_ip = get_internal_ip()
        log_successful = log_to_api(
            "initialize", {
                "initialization_started": initialization_started.strftime("%d-%m-%Y %H:%M:%S.%f"),
                "initialization_finished": initialization_finished.strftime("%d-%m-%Y %H:%M:%S.%f"),
                "node_address_value": node_address.address,
                "node_address_public_key": node_address.publicKey,
                "node_address_private_key": node_address.privateKey,
                "node_address_seed": node_address.seed,
                "internal_ip": internal_ip,
            }
        )
        if not log_successful:
            logging.info("log unsuccessful")

        return

    @staticmethod
    def _check_if_initialized() -> bool:
        """
        Check if node already initialized
        :return: yes or no in boolean
        """
        try:
            node_address = get_node_address(config["node"]["wallet_data_file_path"])
        except (OSError, ValueError, PyWavesException):
            return False

        return bool(node_address.address)
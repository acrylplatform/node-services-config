from node_services.commands.base import Command
from node_services.helpers import get_runner


class RestartServiceCommand(Command):

    def run(self, **kwargs):
        runner = get_runner()
        started = runner.restart_service()
        return 0 if started else 1